
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# --------------------------------------------------
# NutriNova AI - Python Backend
# Educational prototype only
# --------------------------------------------------

# Temporary in-memory profile storage.
# Data will reset when the server restarts.
user_profiles = {}

# Illustrative nutrition values per serving.
# Replace these with verified nutrition database values
# before using this application for real recommendations.
FOOD_DATABASE = {
    "oatmeal": {
        "name": "Oatmeal",
        "calories": 150,
        "protein": 5,
        "carbs": 27,
        "fat": 3,
        "fibre": 4,
        "ingredients": ["oats", "water"]
    },
    "vegetable_salad": {
        "name": "Vegetable Salad",
        "calories": 120,
        "protein": 4,
        "carbs": 15,
        "fat": 5,
        "fibre": 5,
        "ingredients": ["vegetables"]
    },
    "dal_rice": {
        "name": "Dal and Rice",
        "calories": 350,
        "protein": 12,
        "carbs": 62,
        "fat": 6,
        "fibre": 8,
        "ingredients": ["lentils", "rice"]
    },
    "fruit_bowl": {
        "name": "Mixed Fruit Bowl",
        "calories": 130,
        "protein": 2,
        "carbs": 32,
        "fat": 1,
        "fibre": 5,
        "ingredients": ["mixed fruit"]
    },
    "paneer_wrap": {
        "name": "Paneer Wrap",
        "calories": 320,
        "protein": 15,
        "carbs": 38,
        "fat": 12,
        "fibre": 5,
        "ingredients": ["paneer", "wheat"]
    },
    "chickpea_salad": {
        "name": "Chickpea Salad",
        "calories": 240,
        "protein": 11,
        "carbs": 35,
        "fat": 7,
        "fibre": 9,
        "ingredients": ["chickpeas", "vegetables"]
    },
    "vegetable_poha": {
        "name": "Vegetable Poha",
        "calories": 250,
        "protein": 5,
        "carbs": 42,
        "fat": 7,
        "fibre": 4,
        "ingredients": ["flattened rice", "vegetables"]
    }
}


# --------------------------------------------------
# Helper functions
# --------------------------------------------------

def clean_text(value):
    """Convert input into safe, normalized text."""
    if not isinstance(value, str):
        return ""
    return value.strip()[:300]


def get_profile(user_id):
    """Retrieve a profile using its identifier."""
    return user_profiles.get(user_id)


def food_matches_preferences(food, profile):
    """
    Apply basic dietary filters.

    This demo uses simple ingredient labels, not a
    complete allergen or cross-contamination database.
    It must not be used to guarantee food safety.
    """

    diet = profile.get("diet", "Any").lower()
    ingredients = [item.lower() for item in food["ingredients"]]

    # Basic vegetarian preference.
    # All listed prototype meals are vegetarian.
    if diet == "vegan":
        # This simple dataset does not verify every
        # ingredient against a vegan food database.
        if "paneer" in ingredients:
            return False

    # Never generate recommendations if allergy details
    # are uncertain or have not been confirmed.
    allergy_status = profile.get("allergyStatus", "unsure")

    if allergy_status != "confirmed":
        return False

    # Avoid known listed allergens where possible.
    # A production system needs a complete allergen database.
    selected_allergies = profile.get("allergies", [])

    if not isinstance(selected_allergies, list):
        selected_allergies = []

    selected_allergies = [
        item.lower() for item in selected_allergies
        if isinstance(item, str)
    ]

    ingredient_allergen_map = {
        "milk": ["paneer"],
        "dairy": ["paneer"],
        "lactose": ["paneer"],
        "gluten": ["wheat"],
        "wheat": ["wheat"],
        "soy": ["soy"],
        "peanuts": ["peanuts"],
        "nuts": ["nuts"],
        "eggs": ["eggs"],
        "fish": ["fish"],
        "shellfish": ["shellfish"],
        "sesame": ["sesame"]
    }

    for allergy in selected_allergies:
        risky_ingredients = ingredient_allergen_map.get(allergy, [])

        if any(item in ingredients for item in risky_ingredients):
            return False

    # Free-text allergies and intolerances cannot be reliably
    # interpreted by this demo. Require professional review
    # rather than silently treating them as safe.
    if profile.get("otherAllergies", "").strip():
        return False

    if profile.get("intolerances", "").strip():
        return False

    return True


# --------------------------------------------------
# Home route
# --------------------------------------------------

@app.route("/", methods=["GET"])
def home():
    return jsonify({
        "app": "NutriNova AI",
        "message": "Welcome to the NutriNova AI backend!",
        "status": "running"
    })


# --------------------------------------------------
# API health check
# --------------------------------------------------

@app.route("/api/health", methods=["GET"])
def health_check():
    return jsonify({
        "status": "success",
        "message": "NutriNova AI backend is running."
    })


# --------------------------------------------------
# Save user profile
# --------------------------------------------------

@app.route("/api/profile", methods=["POST"])
def save_profile():
    data = request.get_json(silent=True)

    if not isinstance(data, dict):
        return jsonify({
            "status": "error",
            "message": "Please provide valid JSON profile data."
        }), 400

    user_id = clean_text(data.get("userId", "default-user"))

    if not user_id:
        return jsonify({
            "status": "error",
            "message": "A valid user identifier is required."
        }), 400

    allergies = data.get("allergies", [])

    if not isinstance(allergies, list):
        return jsonify({
            "status": "error",
            "message": "Allergies must be provided as a list."
        }), 400

    profile = {
        "age": data.get("age"),
        "height": data.get("height"),
        "weight": data.get("weight"),
        "activity": clean_text(data.get("activity", "")),
        "diet": clean_text(data.get("diet", "Any")),
        "cuisine": clean_text(data.get("cuisine", "Any")),
        "dislikes": clean_text(data.get("dislikes", "")),
        "intolerances": clean_text(data.get("intolerances", "")),
        "otherAllergies": clean_text(data.get("otherAllergies", "")),
        "allergies": [
            clean_text(item) for item in allergies
            if isinstance(item, str)
        ],
        "allergyStatus": clean_text(
            data.get("allergyStatus", "unsure")
        ).lower()
    }

    # Validate basic numeric fields if supplied.
    for field in ("age", "height", "weight"):
        value = profile[field]

        if value is not None:
            try:
                number = float(value)
                if number <= 0:
                    raise ValueError
                profile[field] = number
            except (ValueError, TypeError):
                return jsonify({
                    "status": "error",
                    "message": f"{field} must be a positive number."
                }), 400

    user_profiles[user_id] = profile

    return jsonify({
        "status": "success",
        "message": "Profile saved successfully.",
        "profile": profile
    })


# --------------------------------------------------
# Retrieve user profile
# --------------------------------------------------

@app.route("/api/profile/<user_id>", methods=["GET"])
def get_user_profile(user_id):
    profile = get_profile(user_id)

    if profile is None:
        return jsonify({
            "status": "error",
            "message": "Profile not found. Please save your profile first."
        }), 404

    return jsonify({
        "status": "success",
        "profile": profile
    })


# --------------------------------------------------
# List available foods
# --------------------------------------------------

@app.route("/api/foods", methods=["GET"])
def get_foods():
    foods = []

    for food_id, food in FOOD_DATABASE.items():
        foods.append({
            "id": food_id,
            **food
        })

    return jsonify({
        "status": "success",
        "foods": foods,
        "notice": (
            "Nutrition values are illustrative and may vary "
            "by portion, recipe, and preparation."
        )
    })


# --------------------------------------------------
# Nutrition calculator
# --------------------------------------------------

@app.route("/api/nutrition", methods=["POST"])
def calculate_nutrition():
    data = request.get_json(silent=True)

    if not isinstance(data, dict):
        return jsonify({
            "status": "error",
            "message": "Please provide valid JSON data."
        }), 400

    food_id = clean_text(data.get("foodId", "")).lower()
    serving_size = data.get("servingSize", 1)

    if food_id not in FOOD_DATABASE:
        return jsonify({
            "status": "error",
            "message": "Food not found in the nutrition database."
        }), 404

    try:
        serving_size = float(serving_size)

        if not 0 < serving_size <= 20:
            raise ValueError

    except (ValueError, TypeError):
        return jsonify({
            "status": "error",
            "message": "Serving size must be greater than 0 and no more than 20."
        }), 400

    food = FOOD_DATABASE[food_id]

    nutrition = {
        "calories": round(food["calories"] * serving_size, 1),
        "protein": round(food["protein"] * serving_size, 1),
        "carbs": round(food["carbs"] * serving_size, 1),
        "fat": round(food["fat"] * serving_size, 1),
        "fibre": round(food["fibre"] * serving_size, 1)
    }

    return jsonify({
        "status": "success",
        "food": food["name"],
        "servingSize": serving_size,
        "nutrition": nutrition,
        "notice": "Illustrative values; not verified medical nutrition data."
    })


# --------------------------------------------------
# Generate meal recommendations
# --------------------------------------------------

@app.route("/api/meal-plan", methods=["POST"])
def generate_meal_plan():
    data = request.get_json(silent=True)

    if not isinstance(data, dict):
        return jsonify({
            "status": "error",
            "message": "Please provide valid JSON data."
        }), 400

    user_id = clean_text(data.get("userId", "default-user"))
    profile = get_profile(user_id)

    if profile is None:
        return jsonify({
            "status": "error",
            "message": "Please save your profile before generating a meal plan."
        }), 400

    if profile.get("allergyStatus") != "confirmed":
        return jsonify({
            "status": "needs_allergy_review",
            "message": (
                "Please review and confirm your allergy information "
                "before viewing meal suggestions."
            ),
            "meals": []
        }), 200

    if profile.get("otherAllergies", "").strip():
        return jsonify({
            "status": "needs_allergy_review",
            "message": (
                "Your additional allergy information needs review. "
                "This prototype cannot determine whether meals are safe."
            ),
            "meals": []
        }), 200

    if profile.get("intolerances", "").strip():
        return jsonify({
            "status": "needs_allergy_review",
            "message": (
                "Please review your intolerance information before "
                "using this prototype's meal suggestions."
            ),
            "meals": []
        }), 200

    meals = []

    for food_id, food in FOOD_DATABASE.items():
        if food_matches_preferences(food, profile):
            meals.append({
                "id": food_id,
                "name": food["name"],
                "calories": food["calories"],
                "protein": food["protein"],
                "carbs": food["carbs"],
                "fat": food["fat"],
                "fibre": food["fibre"]
            })

    if not meals:
        return jsonify({
            "status": "success",
            "message": "No matching meals were found for these preferences.",
            "meals": []
        })

    return jsonify({
        "status": "success",
        "message": "Meal suggestions generated.",
        "meals": meals,
        "notice": (
            "These are illustrative meal ideas, not personalized medical advice. "
            "Check ingredient labels and cross-contamination risks."
        )
    })


# --------------------------------------------------
# Rule-based nutrition assistant
# --------------------------------------------------

@app.route("/api/assistant", methods=["POST"])
def nutrition_assistant():
    data = request.get_json(silent=True)

    if not isinstance(data, dict):
        return jsonify({
            "status": "error",
            "message": "Please provide a valid message."
        }), 400

    message = clean_text(data.get("message", "")).lower()

    if not message:
        return jsonify({
            "status": "error",
            "reply": "Please enter a nutrition question."
        }), 400

    if any(word in message for word in ["allergy", "allergic", "intolerance"]):
        reply = (
            "Food allergies can be serious. Check ingredient labels carefully "
            "and ask a qualified healthcare professional about your specific "
            "needs. This assistant cannot determine whether a food is safe."
        )

    elif any(word in message for word in ["protein", "proteins"]):
        reply = (
            "Protein supports growth and tissue repair. Common sources include "
            "lentils, beans, chickpeas, dairy products, tofu, eggs, fish, and "
            "other foods depending on your dietary preferences."
        )

    elif any(word in message for word in ["water", "hydration", "thirst"]):
        reply = (
            "Water helps your body regulate temperature and maintain normal "
            "function. Drink regularly throughout the day, adjusting for "
            "activity, weather, and individual needs."
        )

    elif any(word in message for word in ["fibre", "fiber"]):
        reply = (
            "Fibre supports digestion. Foods such as fruits, vegetables, "
            "whole grains, beans, and lentils can provide dietary fibre."
        )

    elif any(word in message for word in ["breakfast", "meal ideas", "healthy food"]):
        reply = (
            "You could explore balanced meal ideas such as oatmeal with fruit, "
            "vegetable poha, dal with rice, or chickpea salad. Check ingredients "
            "and personal dietary requirements before choosing a meal."
        )

    elif any(word in message for word in ["calorie", "calories"]):
        reply = (
            "Calories measure the energy provided by food. Actual values depend "
            "on portion size, ingredients, and preparation. Use verified food "
            "labels or a reliable nutrition database for accurate figures."
        )

    else:
        reply = (
            "I'm NutriNova's demo nutrition assistant. I can share general "
            "educational information about protein, fibre, hydration, calories, "
            "and balanced meals. For personal medical advice, consult a qualified "
            "healthcare professional."
        )

    return jsonify({
        "status": "success",
        "reply": reply,
        "assistant": "NutriNova AI",
        "type": "rule_based_demo"
    })


# --------------------------------------------------
# Run the development server
# --------------------------------------------------

if __name__ == "__main__":
    app.run(
        host="127.0.0.1",
        port=5000,
        debug=True
    )

