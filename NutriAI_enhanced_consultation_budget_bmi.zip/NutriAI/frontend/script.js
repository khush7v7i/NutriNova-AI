"use strict";

/* =====================================================
   NUTRINOVA AI
   Frontend JavaScript
   ===================================================== */

const $ = (selector) => document.querySelector(selector);

const PROFILE_KEY = "nutriNovaProfile";
const SAVED_MEALS_KEY = "nutriNovaSavedMeals";
const ASSISTANT_LANGUAGE_KEY = "nutriNovaAssistantLanguage";

let toastTimer;
let assistantLanguage = "en";

/* =====================================================
   1. TOAST NOTIFICATIONS
   ===================================================== */

function showToast(message) {
    const toast = $("#toast");

    if (!toast) return;

    toast.textContent = message;
    toast.classList.add("show");

    clearTimeout(toastTimer);

    toastTimer = setTimeout(() => {
        toast.classList.remove("show");
    }, 3000);
}

/* =====================================================
   2. NAVIGATION
   ===================================================== */

const validPages = [
    "home",
    "profile",
    "planner",
    "budget-planner",
    "consultation",
    "cycle",
    "pregnancy",
    "local-foods",
    "nutrition",
    "assistant",
    "learn"
];

function showPage(pageId) {
    if (!validPages.includes(pageId)) {
        pageId = "home";
    }

    document.querySelectorAll(".page-section").forEach(section => {
        section.classList.add("hidden");
    });

    const page = document.getElementById(pageId);

    if (!page) return;

    page.classList.remove("hidden");

    document.querySelectorAll(".nav-link").forEach(link => {
        link.classList.toggle(
            "active",
            link.getAttribute("href") === `#${pageId}`
        );
    });

    $("#navLinks")?.classList.remove("open");

    if (window.location.hash !== `#${pageId}`) {
        history.replaceState(null, "", `#${pageId}`);
    }

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

    if (pageId === "planner") {
        updatePlannerSummary();
    }

    if (pageId === "cycle") {
        renderPeriodMeals();
    }

    if (pageId === "local-foods") {
        renderLocalFoods();
    }
}

document.querySelectorAll("[data-go]").forEach(button => {
    button.addEventListener("click", () => {
        showPage(button.dataset.go);
    });
});

document.querySelectorAll(".nav-link").forEach(link => {
    link.addEventListener("click", event => {
        event.preventDefault();

        showPage(
            link.getAttribute("href").substring(1)
        );
    });
});

$("#menuButton")?.addEventListener("click", () => {
    $("#navLinks")?.classList.toggle("open");
});

window.addEventListener("hashchange", () => {
    const pageId = location.hash.substring(1);

    if (validPages.includes(pageId)) {
        showPage(pageId);
    }
});

/* =====================================================
   3. PROFILE MANAGEMENT
   ===================================================== */

function getProfile() {
    try {
        return JSON.parse(
            localStorage.getItem(PROFILE_KEY)
        ) || null;
    } catch (error) {
        console.error("Profile loading error:", error);
        return null;
    }
}

function readProfileForm() {
    return {
        name: $("#profileName").value.trim(),
        age: $("#age").value,
        sex: $("#sex").value,
        weight: $("#weight").value,
        height: $("#height").value,
        activity: $("#activity").value,
        dietPreference: $("#dietPreference").value,
        cuisine: $("#cuisine").value,
        allergies: $("#allergies").value.trim(),
        intolerances: $("#intolerances").value.trim(),
        dislikes: $("#dislikes").value.trim()
    };
}

function populateProfileForm(profile) {
    if (!profile) return;

    const fields = {
        profileName: profile.name,
        age: profile.age,
        sex: profile.sex,
        weight: profile.weight,
        height: profile.height,
        activity: profile.activity,
        dietPreference: profile.dietPreference,
        cuisine: profile.cuisine,
        allergies: profile.allergies,
        intolerances: profile.intolerances,
        dislikes: profile.dislikes
    };

    Object.entries(fields).forEach(([id, value]) => {
        const element = document.getElementById(id);

        if (element && value !== undefined && value !== null) {
            element.value = value;
        }
    });
}

function saveProfile(profile) {
    localStorage.setItem(
        PROFILE_KEY,
        JSON.stringify(profile)
    );
}

$("#profileForm")?.addEventListener("submit", event => {
    event.preventDefault();

    const profile = readProfileForm();

    if (!profile.name) {
        $("#profileStatus").textContent =
            "Please enter your name.";
        return;
    }

    const age = Number(profile.age);

    if (!Number.isFinite(age) || age < 1 || age > 120) {
        $("#profileStatus").textContent =
            "Please enter a valid age.";
        return;
    }

    if (
        profile.weight &&
        (!Number.isFinite(Number(profile.weight)) ||
         Number(profile.weight) <= 0)
    ) {
        $("#profileStatus").textContent =
            "Please enter a valid weight.";
        return;
    }

    if (
        profile.height &&
        (!Number.isFinite(Number(profile.height)) ||
         Number(profile.height) <= 0)
    ) {
        $("#profileStatus").textContent =
            "Please enter a valid height.";
        return;
    }

    try {
        saveProfile(profile);

        $("#profileStatus").textContent =
            "Your profile has been saved successfully!";

        updatePlannerSummary();
        updateBMIDisplay();
        showToast("Profile saved successfully!");
    } catch (error) {
        $("#profileStatus").textContent =
            "Unable to save your profile in this browser.";
    }
});

$("#clearProfile")?.addEventListener("click", () => {
    if (!confirm("Clear your saved profile?")) return;

    localStorage.removeItem(PROFILE_KEY);

    $("#profileForm").reset();

    $("#profileStatus").textContent =
        "Profile cleared.";

    updatePlannerSummary();
    updateBMIDisplay();
    showToast("Saved profile cleared.");
});

function updatePlannerSummary() {
    const profile = getProfile();

    if (!profile) {
        $("#plannerName").textContent = "there";

        $("#plannerProfileSummary").textContent =
            "Save your profile first to personalize your suggestions.";

        return;
    }

    $("#plannerName").textContent =
        profile.name || "there";

    $("#plannerProfileSummary").textContent =
        `${profile.dietPreference} preference · ` +
        `${profile.cuisine} cuisine · ` +
        "Suggestions use your saved food preferences.";
}

/* =====================================================
   4. MEAL DATABASE
   ===================================================== */

const meals = [
    {
        id: "oats",
        name: "Fruit Oatmeal",
        type: "Breakfast",
        diet: ["vegetarian", "vegan", "eggetarian", "non-vegetarian"],
        ingredients: ["oats", "banana", "apple"],
        description: "Oats with fruit for a simple breakfast.",
        calories: 280,
        protein: 8,
        image: "https://images.unsplash.com/photo-1517673132405-a56a62b18caf?auto=format&fit=crop&w=800&q=80"
    },
    {
        id: "poha",
        name: "Vegetable Poha",
        type: "Breakfast",
        diet: ["vegetarian", "vegan", "eggetarian", "non-vegetarian"],
        ingredients: ["rice flakes", "vegetables", "peanuts"],
        description: "Flattened rice with vegetables and peanuts.",
        calories: 250,
        protein: 6,
        image: "https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=800&q=80"
    },
    {
        id: "besan",
        name: "Besan Chilla",
        type: "Breakfast",
        diet: ["vegetarian", "vegan", "eggetarian", "non-vegetarian"],
        ingredients: ["besan", "gram flour", "vegetables"],
        description: "A savoury chickpea-flour pancake.",
        calories: 220,
        protein: 10,
        image: ""
    },
    {
        id: "eggs",
        name: "Egg Omelette",
        type: "Breakfast",
        diet: ["eggetarian", "non-vegetarian"],
        ingredients: ["eggs", "onion", "tomato"],
        description: "Eggs cooked with vegetables.",
        calories: 190,
        protein: 13,
        image: ""
    },
    {
        id: "paneer",
        name: "Paneer Bhurji",
        type: "Lunch",
        diet: ["vegetarian", "eggetarian", "non-vegetarian"],
        ingredients: ["paneer", "milk", "tomato", "onion"],
        description: "Crumbled paneer with mild spices.",
        calories: 300,
        protein: 18,
        image: ""
    },
    {
        id: "rajma",
        name: "Rajma Chawal",
        type: "Lunch",
        diet: ["vegetarian", "vegan", "eggetarian", "non-vegetarian"],
        ingredients: ["rajma", "kidney beans", "rice"],
        description: "Kidney beans served with rice.",
        calories: 380,
        protein: 14,
        image: ""
    },
    {
        id: "dal",
        name: "Dal and Roti",
        type: "Lunch",
        diet: ["vegetarian", "vegan", "eggetarian", "non-vegetarian"],
        ingredients: ["dal", "lentils", "wheat", "roti"],
        description: "A familiar combination of lentils and roti.",
        calories: 350,
        protein: 13,
        image: ""
    },
    {
        id: "khichdi",
        name: "Vegetable Khichdi",
        type: "Dinner",
        diet: ["vegetarian", "vegan", "eggetarian", "non-vegetarian"],
        ingredients: ["rice", "moong dal", "vegetables"],
        description: "Rice and lentils cooked with vegetables.",
        calories: 320,
        protein: 12,
        image: ""
    },
    {
        id: "fruit",
        name: "Seasonal Fruit Bowl",
        type: "Snack",
        diet: ["vegetarian", "vegan", "eggetarian", "non-vegetarian"],
        ingredients: ["apple", "banana", "guava", "seasonal fruit"],
        description: "A refreshing mix of seasonal fruit.",
        calories: 150,
        protein: 3,
        image: ""
    },
    {
        id: "sprouts",
        name: "Sprout Salad",
        type: "Snack",
        diet: ["vegetarian", "vegan", "eggetarian", "non-vegetarian"],
        ingredients: ["sprouts", "moong", "lemon", "vegetables"],
        description: "Sprouts with lemon and fresh vegetables.",
        calories: 180,
        protein: 10,
        image: ""
    },
    {
        id: "dalia",
        name: "Vegetable Dalia",
        type: "Breakfast",
        diet: ["vegetarian", "vegan", "eggetarian", "non-vegetarian"],
        ingredients: ["dalia", "wheat", "vegetables"],
        description: "Broken wheat cooked with vegetables.",
        calories: 240,
        protein: 7,
        image: ""
    },
    {
        id: "chana",
        name: "Kala Chana",
        type: "Lunch",
        diet: ["vegetarian", "vegan", "eggetarian", "non-vegetarian"],
        ingredients: ["chana", "chickpeas", "lemon"],
        description: "Black chickpeas with spices and lemon.",
        calories: 270,
        protein: 13,
        image: ""
    },
    {
        id: "soup",
        name: "Vegetable Soup",
        type: "Dinner",
        diet: ["vegetarian", "vegan", "eggetarian", "non-vegetarian"],
        ingredients: ["vegetables"],
        description: "A warm vegetable-based soup.",
        calories: 120,
        protein: 4,
        image: ""
    }
];

/* =====================================================
   5. ALLERGY AND FOOD-PREFERENCE FILTERING
   ===================================================== */

function getBlockedTerms(profile) {
    const raw = [
        profile?.allergies,
        profile?.intolerances,
        profile?.dislikes
    ].filter(Boolean).join(",");

    return raw
        .split(",")
        .map(term => term.trim().toLowerCase())
        .filter(Boolean);
}

function isMealSuitable(meal, profile) {
    if (!profile) return true;

    const diet = profile.dietPreference || "vegetarian";

    if (!meal.diet.includes(diet)) {
        return false;
    }

    const blockedTerms = getBlockedTerms(profile);

    const searchableText = [
        meal.name,
        meal.description,
        ...meal.ingredients
    ].join(" ").toLowerCase();

    return !blockedTerms.some(term => {
        return searchableText.includes(term);
    });
}

/* =====================================================
   6. MEAL PLANNER
   ===================================================== */

function getSavedMeals() {
    try {
        return JSON.parse(
            localStorage.getItem(SAVED_MEALS_KEY)
        ) || [];
    } catch {
        return [];
    }
}

function toggleSavedMeal(mealId) {
    const saved = getSavedMeals();

    const exists = saved.includes(mealId);

    const updated = exists
        ? saved.filter(id => id !== mealId)
        : [...saved, mealId];

    localStorage.setItem(
        SAVED_MEALS_KEY,
        JSON.stringify(updated)
    );

    showToast(
        exists ? "Meal removed from saved meals." :
                 "Meal saved successfully!"
    );

    renderMealCards();
}

function renderMealCards() {
    const grid = $("#mealGrid");

    if (!grid) return;

    const profile = getProfile();

    if (!profile) {
        grid.innerHTML = `
            <div class="empty-state">
                <span>🥗</span>
                <h3>Create your profile first</h3>
                <p>Save your preferences to generate meal ideas.</p>
                <button class="btn btn-primary" data-go="profile">
                    Create profile
                </button>
            </div>
        `;

        grid.querySelector("[data-go]")?.addEventListener(
            "click",
            () => showPage("profile")
        );

        return;
    }

    const suitableMeals = meals.filter(
        meal => isMealSuitable(meal, profile)
    );

    if (!suitableMeals.length) {
        grid.innerHTML = `
            <div class="empty-state">
                <span>🔎</span>
                <h3>No suitable meal suggestions found</h3>
                <p>
                    Review your food preferences and blocked ingredients.
                    If you have allergies, verify every ingredient manually.
                </p>
            </div>
        `;

        return;
    }

    const saved = getSavedMeals();

    grid.innerHTML = suitableMeals.map(meal => `
        <article class="meal-card">
            ${
                meal.image
                    ? `<img src="${meal.image}"
                         alt="${meal.name}"
                         loading="lazy">`
                    : `<div class="meal-placeholder"
                         role="img"
                         aria-label="${meal.name}">
                         🥗
                       </div>`
            }

            <div class="meal-card-content">
                <span class="meal-tag">${meal.type}</span>

                <h3>${meal.name}</h3>

                <p>${meal.description}</p>

                <p class="meal-meta">
                    Approx. ${meal.calories} kcal ·
                    ${meal.protein} g protein
                </p>

                <button class="save-meal"
                        data-save-meal="${meal.id}">
                    ${saved.includes(meal.id)
                        ? "✓ Saved"
                        : "♡ Save meal"}
                </button>
            </div>
        </article>
    `).join("");

    grid.querySelectorAll("[data-save-meal]").forEach(button => {
        button.addEventListener("click", () => {
            toggleSavedMeal(button.dataset.saveMeal);
        });
    });
}

$("#generateMeals")?.addEventListener("click", () => {
    if (!getProfile()) {
        $("#mealStatus").textContent =
            "Please save your profile first.";

        showToast("Create your profile first.");
        return;
    }

    $("#mealStatus").textContent =
        "Meal suggestions generated from your saved preferences.";

    renderMealCards();
    showToast("Your meal suggestions are ready!");
});

/* =====================================================
   7. NUTRITION CALCULATOR
   ===================================================== */

/*
 Values are approximate per 100 g of food.
 Actual values vary with ingredients and preparation.
*/

const nutritionDatabase = {
    rice: {
        calories: 130,
        protein: 2.7,
        carbs: 28.2,
        fat: 0.3
    },

    roti: {
        calories: 297,
        protein: 9.8,
        carbs: 55.0,
        fat: 7.0
    },

    dal: {
        calories: 116,
        protein: 9.0,
        carbs: 20.0,
        fat: 0.4
    },

    egg: {
        calories: 155,
        protein: 13.0,
        carbs: 1.1,
        fat: 11.0
    },

    banana: {
        calories: 89,
        protein: 1.1,
        carbs: 22.8,
        fat: 0.3
    },

    apple: {
        calories: 52,
        protein: 0.3,
        carbs: 13.8,
        fat: 0.2
    },

    milk: {
        calories: 61,
        protein: 3.2,
        carbs: 4.8,
        fat: 3.3
    },

    oats: {
        calories: 71,
        protein: 2.5,
        carbs: 12.0,
        fat: 1.5
    },

    paneer: {
        calories: 265,
        protein: 18.3,
        carbs: 1.2,
        fat: 20.8
    },

    chicken: {
        calories: 165,
        protein: 31.0,
        carbs: 0,
        fat: 3.6
    }
};

$("#calculateNutrition")?.addEventListener("click", () => {
    const food = $("#foodSelect").value;
    const serving = Number($("#serving").value);

    if (
        !Number.isFinite(serving) ||
        serving <= 0 ||
        serving > 2000
    ) {
        showToast("Enter a serving between 1 and 2000 grams.");
        return;
    }

    const values = nutritionDatabase[food];

    if (!values) {
        showToast("Nutrition information is unavailable.");
        return;
    }

    const factor = serving / 100;

    $("#caloriesResult").textContent =
        (values.calories * factor).toFixed(1);

    $("#proteinResult").textContent =
        (values.protein * factor).toFixed(1);

    $("#carbsResult").textContent =
        (values.carbs * factor).toFixed(1);

    $("#fatResult").textContent =
        (values.fat * factor).toFixed(1);

    $("#nutritionResults").classList.remove("hidden");
});

/* =====================================================
   8. NUTRITION ASSISTANT
   ===================================================== */

const assistantResponses = [
    {
        keywords: ["balanced meal", "balanced diet", "संतुलित भोजन", "संतुलित आहार", "संतुलित डाइट"],
        answer:
            "A balanced meal generally combines vegetables or fruit, " +
            "a grain or other energy source, and protein-rich foods. " +
            "Examples include dal, rice, vegetables and curd, adjusted " +
            "to your preferences and needs.",
        answerHi:
            "संतुलित भोजन में आमतौर पर सब्ज़ियाँ या फल, ऊर्जा देने वाला अनाज " +
            "और प्रोटीन वाले खाद्य पदार्थ शामिल होते हैं। उदाहरण के लिए दाल, " +
            "चावल, सब्ज़ी और दही ले सकते हैं। मात्रा और चुनाव आपकी ज़रूरतों " +
            "और पसंद के अनुसार रखें।"
    },
    {
        keywords: ["protein", "प्रोटीन", "प्रोटीन के स्रोत", "प्रोटीन क्या"],
        answer:
            "Protein helps build and repair body tissues. Common sources " +
            "include lentils, rajma, chickpeas, paneer, milk, eggs, soy " +
            "foods and meat. Your needs depend on age, activity and health.",
        answerHi:
            "प्रोटीन शरीर की मांसपेशियों और अन्य ऊतकों को बनाने तथा उनकी मरम्मत " +
            "में मदद करता है। इसके अच्छे स्रोतों में दालें, राजमा, चना, पनीर, " +
            "दूध, अंडे और सोया खाद्य पदार्थ शामिल हैं। आपकी ज़रूरत उम्र, " +
            "शारीरिक गतिविधि और स्वास्थ्य पर निर्भर करती है।"
    },
    {
        keywords: ["hydration", "water", "dehydration", "पानी", "जलयोजन", "हाइड्रेशन", "निर्जलीकरण", "पानी पीना"],
        answer:
            "Hydration supports temperature regulation and normal body " +
            "functions. During trekking, fluid needs may increase with " +
            "effort, heat and altitude. Drink regularly and follow local " +
            "water-safety guidance.",
        answerHi:
            "पर्याप्त पानी पीना शरीर का तापमान नियंत्रित रखने और सामान्य " +
            "शारीरिक कार्यों में मदद करता है। गर्मी, व्यायाम या ट्रेकिंग के " +
            "दौरान पानी की ज़रूरत बढ़ सकती है। नियमित रूप से पानी पिएँ और " +
            "सुरक्षित पेयजल का उपयोग करें।"
    },
    {
        keywords: ["fibre", "fiber", "dietary fibre", "फाइबर", "रेशा", "आहारीय रेशा"],
        answer:
            "Dietary fibre supports digestive health. Sources include " +
            "whole grains, pulses, fruit, vegetables, nuts and seeds. " +
            "Increase fibre gradually and drink enough fluids.",
        answerHi:
            "आहार में मौजूद फाइबर पाचन स्वास्थ्य को सहारा देता है। इसके स्रोत " +
            "साबुत अनाज, दालें, फल, सब्ज़ियाँ, मेवे और बीज हैं। फाइबर की " +
            "मात्रा धीरे-धीरे बढ़ाएँ और पर्याप्त तरल पदार्थ लें।"
    },
    {
        keywords: ["iron", "anaemia", "anemia", "आयरन", "लोहा", "खून की कमी", "एनीमिया", "हीमोग्लोबिन"],
        answer:
            "Iron sources include lentils, beans and leafy greens; eggs " +
            "and meat also provide iron if eaten. Vitamin C foods such as " +
            "lemon, guava and oranges can help the body absorb plant iron. " +
            "A clinician can assess suspected iron deficiency.",
        answerHi:
            "आयरन के स्रोतों में दालें, बीन्स और हरी पत्तेदार सब्ज़ियाँ शामिल हैं। " +
            "अंडे और मांस भी आयरन देते हैं, यदि आप इन्हें खाते हैं। नींबू, " +
            "अमरूद और संतरे जैसे विटामिन C वाले खाद्य पदार्थ पौधों से मिलने " +
            "वाले आयरन के अवशोषण में मदद कर सकते हैं। खून की कमी का संदेह " +
            "हो तो स्वास्थ्यकर्मी से जाँच करवाएँ।"
    },
    {
        keywords: ["period", "menstrual", "cramp", "मासिक धर्म", "पीरियड", "माहवारी", "मासिक", "ऐंठन"],
        answer:
            "During menstruation, regular meals, fluids and iron-containing " +
            "foods may help support general nutrition. Try the Cycle Care " +
            "section for flexible meal ideas. Severe pain or heavy bleeding " +
            "deserves medical assessment.",
        answerHi:
            "मासिक धर्म के दौरान नियमित भोजन, पर्याप्त तरल पदार्थ और आयरन वाले " +
            "खाद्य पदार्थ सामान्य पोषण में मदद कर सकते हैं। भोजन के सुझावों के " +
            "लिए Cycle Care अनुभाग देखें। तेज़ दर्द या बहुत अधिक रक्तस्राव " +
            "होने पर चिकित्सकीय सलाह लें।"
    },
    {
        keywords: ["pregnancy", "pregnant", "गर्भावस्था", "गर्भवती", "प्रेग्नेंसी", "प्रेगनेंसी"],
        answer:
            "Pregnancy nutrition needs vary by person and stage. The " +
            "Pregnancy Plan section contains general meal ideas only. " +
            "Discuss supplements, food safety and individual requirements " +
            "with your antenatal-care professional.",
        answerHi:
            "गर्भावस्था में पोषण की ज़रूरतें व्यक्ति और गर्भावस्था के चरण के " +
            "अनुसार बदलती हैं। Pregnancy Plan अनुभाग में केवल सामान्य भोजन " +
            "के सुझाव हैं। सप्लीमेंट, खाद्य सुरक्षा और व्यक्तिगत ज़रूरतों के " +
            "लिए अपने प्रसव-पूर्व देखभाल विशेषज्ञ से सलाह लें।"
    },
    {
        keywords: ["trek", "trekking", "mountain", "hiking", "ट्रेक", "ट्रेकिंग", "पहाड़", "पर्वत", "लंबी पैदल यात्रा"],
        answer:
            "For trekking, plan meals and snacks that provide energy, " +
            "include protein-containing foods and allow regular hydration. " +
            "Check food and safe drinking-water availability before " +
            "setting out. Explore the Uttarakhand Local Food Finder.",
        answerHi:
            "ट्रेकिंग के लिए ऐसे भोजन और स्नैक्स रखें जो ऊर्जा दें; इनमें " +
            "प्रोटीन वाले खाद्य पदार्थ भी शामिल करें और नियमित रूप से पानी पिएँ। " +
            "यात्रा शुरू करने से पहले भोजन और सुरक्षित पेयजल की उपलब्धता जाँचें। " +
            "उत्तराखंड के स्थानीय व्यंजनों के लिए Local Food Finder देखें।"
    },
    {
        keywords: ["local food", "uttarakhand", "garhwali", "kumaoni", "स्थानीय भोजन", "उत्तराखंड", "गढ़वाली", "कुमाऊँनी", "कुमाउनी", "मंडुआ", "भट्ट की चुड़कानी"],
        answer:
            "Explore regional dishes such as Mandua Roti, Bhatt ki " +
            "Churkani, Jhangora Kheer and Rajma in the Local Foods section. " +
            "Restaurant menus and availability should be confirmed directly.",
        answerHi:
            "Local Foods अनुभाग में मंडुआ रोटी, भट्ट की चुड़कानी, झंगोरा की खीर " +
            "और राजमा जैसे क्षेत्रीय व्यंजनों के बारे में जानें। किसी रेस्तराँ " +
            "का मेन्यू और उपलब्धता सीधे वहाँ से पुष्टि करें।"
    }
];

function getAssistantResponse(question) {
    const text = question.toLocaleLowerCase();
    // Hindi-script input receives Hindi output automatically; the selector
    // remains the source of truth when the user types in English.
    const hasHindiScript = /[\u0900-\u097F]/.test(question);
    const useHindi = assistantLanguage === "hi" || hasHindiScript;

    if (
        text.includes("my profile") ||
        text.includes("my meal") ||
        text.includes("मेरी प्रोफ़ाइल") ||
        text.includes("मेरी प्रोफाइल") ||
        text.includes("मेरे भोजन") ||
        text.includes("मेरे खाने") ||
        text.includes("मेरी डाइट")
    ) {
        const profile = getProfile();

        if (!profile) {
            return useHindi
                ? "कृपया पहले अपनी प्रोफ़ाइल सेव करें। फिर सुझाव देखने के लिए Meal Planner खोलें।"
                : "Please save your profile first. Then open the Meal Planner to explore suggestions.";
        }

        return useHindi
            ? `नमस्ते ${profile.name}! आपकी सेव की गई भोजन-पसंद है: ${profile.dietPreference}। आपकी प्रोफ़ाइल के आधार पर सुझाव देखने के लिए Meal Planner खोलें।`
            : `Hello ${profile.name}! Your saved preference is ` +
                `${profile.dietPreference}. Open the Meal Planner to see ` +
                `meal suggestions based on your profile.`;
    }

    const match = assistantResponses.find(item =>
        item.keywords.some(keyword => text.includes(keyword.toLocaleLowerCase()))
    );

    if (match) return useHindi ? match.answerHi : match.answer;

    return useHindi
        ? "मैं संतुलित भोजन, प्रोटीन, फाइबर, आयरन, पानी, मासिक धर्म के दौरान पोषण, गर्भावस्था के सामान्य पोषण और ट्रेकिंग के भोजन पर सामान्य जानकारी दे सकता/सकती हूँ। इनमें से किसी विषय के बारे में पूछें। यह नियम-आधारित प्रोटोटाइप है और चिकित्सकीय निदान नहीं करता।"
        : "I can help with general nutrition education, protein, fibre, " +
            "iron, hydration, menstruation, pregnancy nutrition and trekking " +
            "food planning. Try asking about one of these topics. This " +
            "prototype is rule-based and does not provide medical diagnosis.";
}

const assistantWelcomeMessages = {
    en: "Hello! 👋 I'm your NutriNova learning guide. Ask me about balanced meals, protein, fibre, hydration, or your saved meal preferences.",
    hi: "नमस्ते! 👋 मैं NutriNova का पोषण मार्गदर्शक हूँ। संतुलित भोजन, प्रोटीन, फाइबर, पानी या अपनी सेव की गई भोजन-पसंद के बारे में पूछें।"
};

function updateAssistantLanguageUI(language) {
    const isHindi = language === "hi";

    const assistantSection = $("#assistant");
    if (assistantSection) assistantSection.lang = isHindi ? "hi" : "en";

    const setText = (selector, en, hi) => {
        const element = $(selector);
        if (element) element.textContent = isHindi ? hi : en;
    };

    setText("#assistantHeadingEyebrow", "YOUR NUTRITION LEARNING SPACE", "आपकी पोषण जानकारी का स्थान");
    const title = $("#assistantHeadingTitle");
    if (title) title.innerHTML = isHindi ? "आइए <em>पोषण</em> पर बात करें।" : "Let's talk <em>nutrition.</em>";
    setText("#assistantHeadingDescription", "Ask questions about food, nutrients, and balanced eating.", "भोजन, पोषक तत्वों और संतुलित आहार के बारे में सवाल पूछें।");
    setText("#chatSidebarTitle", "Try asking", "यह पूछकर देखें");
    setText("#assistantEducationalNote", "Educational information only.", "केवल शैक्षिक जानकारी।");
    setText("#assistantDisplayName", "NutriNova Guide", "NutriNova मार्गदर्शक");
    setText("#assistantDisplaySubtitle", "Nutrition learning assistant", "पोषण संबंधी जानकारी सहायक");
    setText("#assistantLanguageLabel", "Language / भाषा", "भाषा / Language");
    setText("#clearChat", "Clear", "चैट साफ़ करें");
    setText("#sendChatButton", "Send ↗", "भेजें ↗");
    setText("#chatFootnote", "Rule-based prototype · No live AI API connected", "नियम-आधारित प्रोटोटाइप · कोई लाइव AI API जुड़ा नहीं है");

    const input = $("#chatInput");
    if (input) {
        input.placeholder = isHindi ? "पोषण से जुड़ा सवाल पूछें..." : "Ask a nutrition question...";
        input.lang = isHindi ? "hi" : "en";
    }
    const messagesRegion = $("#chatMessages");
    if (messagesRegion) messagesRegion.lang = isHindi ? "hi" : "en";

    document.querySelectorAll(".prompt-chip").forEach(button => {
        const label = isHindi ? button.dataset.labelHi : button.dataset.labelEn;
        if (label) button.textContent = label;
    });

    const voiceButton = $("#voiceInputButton");
    if (voiceButton && !voiceButton.disabled) {
        voiceButton.setAttribute("aria-label", isHindi ? "आवाज़ से सवाल बोलें" : "Start voice input");
        voiceButton.title = isHindi ? "अपना सवाल बोलें" : "Speak your question";
    }

    const status = $("#voiceInputStatus");
    if (status && status.textContent.trim()) {
        status.textContent = isHindi
            ? "हिंदी में बोलने के लिए भाषा में हिन्दी चुनें; लिखे गए सवाल को भेजने से पहले जाँच लें।"
            : "Choose English for English speech input. Review voice text before sending.";
    }

    const messages = $("#chatMessages");
    if (messages && messages.children.length === 1 && messages.firstElementChild?.classList.contains("assistant-message")) {
        messages.firstElementChild.textContent = assistantWelcomeMessages[language];
    }
}

function setAssistantLanguage(language) {
    assistantLanguage = language === "hi" ? "hi" : "en";
    try {
        localStorage.setItem(ASSISTANT_LANGUAGE_KEY, assistantLanguage);
    } catch (error) {
        // The language selector remains usable when storage is unavailable.
    }
    const languageSelect = $("#assistantLanguage");
    if (languageSelect) languageSelect.value = assistantLanguage;
    updateAssistantLanguageUI(assistantLanguage);
}

$("#assistantLanguage")?.addEventListener("change", event => {
    setAssistantLanguage(event.target.value);
});

try {
    setAssistantLanguage(localStorage.getItem(ASSISTANT_LANGUAGE_KEY) || "en");
} catch (error) {
    setAssistantLanguage("en");
}

function addChatMessage(text, sender) {
    const messages = $("#chatMessages");

    const message = document.createElement("div");

    message.className =
        sender === "user"
            ? "message user-message"
            : "message assistant-message";

    message.textContent = text;

    messages.appendChild(message);

    messages.scrollTop = messages.scrollHeight;
}

function submitChatQuestion(question) {
    if (!question.trim()) return;

    addChatMessage(question, "user");

    const answer = getAssistantResponse(question);

    setTimeout(() => {
        addChatMessage(answer, "assistant");
    }, 250);
}

$("#chatForm")?.addEventListener("submit", event => {
    event.preventDefault();

    const input = $("#chatInput");
    const question = input.value.trim();

    if (!question) return;

    input.value = "";

    submitChatQuestion(question);
});

document.querySelectorAll(".prompt-chip").forEach(button => {
    button.addEventListener("click", () => {
        const prompt = assistantLanguage === "hi"
            ? (button.dataset.promptHi || button.dataset.prompt || "")
            : (button.dataset.prompt || "");
        submitChatQuestion(prompt);
    });
});

/* Voice-to-text input (uses the browser's built-in speech recognition). */
(function setupVoiceInput() {
    const voiceButton = $("#voiceInputButton");
    const chatInput = $("#chatInput");
    const status = $("#voiceInputStatus");

    if (!voiceButton || !chatInput || !status) return;

    const SpeechRecognition =
        window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!SpeechRecognition) {
        voiceButton.disabled = true;
        voiceButton.title = assistantLanguage === "hi"
            ? "इस ब्राउज़र में वॉइस इनपुट उपलब्ध नहीं है"
            : "Voice input is not supported by this browser";
        voiceButton.setAttribute("aria-label", assistantLanguage === "hi"
            ? "वॉइस इनपुट उपलब्ध नहीं है"
            : "Voice input unavailable");
        status.textContent = assistantLanguage === "hi"
            ? "इस ब्राउज़र में वॉइस इनपुट उपलब्ध नहीं है। आप अपना सवाल टाइप कर सकते हैं।"
            : "Voice input is not supported in this browser. You can type your question instead.";
        return;
    }

    let recognition;
    let isListening = false;
    let finalTranscript = "";
    let inputBeforeRecognition = "";

    function setListening(listening) {
        isListening = listening;
        voiceButton.classList.toggle("is-listening", listening);
        voiceButton.setAttribute("aria-pressed", String(listening));
        voiceButton.setAttribute(
            "aria-label",
            assistantLanguage === "hi"
                ? (listening ? "आवाज़ सुनना बंद करें" : "आवाज़ से सवाल बोलें")
                : (listening ? "Stop voice input" : "Start voice input")
        );
        voiceButton.title = assistantLanguage === "hi"
            ? (listening ? "सुनना बंद करें" : "अपना सवाल बोलें")
            : (listening ? "Stop listening" : "Speak your question");
        voiceButton.textContent = listening ? "⏹️" : "🎙️";
    }

    voiceButton.addEventListener("click", () => {
        if (isListening && recognition) {
            recognition.stop();
            status.textContent = assistantLanguage === "hi"
                ? "आवाज़ दर्ज की जा रही है…"
                : "Finishing voice input…";
            return;
        }

        try {
            recognition = new SpeechRecognition();
            recognition.lang = assistantLanguage === "hi" ? "hi-IN" : "en-IN";
            recognition.interimResults = true;
            recognition.continuous = false;
            finalTranscript = "";
            inputBeforeRecognition = chatInput.value.trim();

            recognition.onstart = () => {
                setListening(true);
                status.textContent = assistantLanguage === "hi"
                    ? "सुन रहा हूँ… अपना सवाल साफ़-साफ़ बोलें।"
                    : "Listening… Speak your question clearly.";
            };

            recognition.onresult = event => {
                let interimTranscript = "";

                for (let i = event.resultIndex; i < event.results.length; i += 1) {
                    const transcript = event.results[i][0].transcript;
                    if (event.results[i].isFinal) {
                        finalTranscript += transcript;
                    } else {
                        interimTranscript += transcript;
                    }
                }

                const recognizedText = (finalTranscript + " " + interimTranscript).trim();
                if (recognizedText) {
                    const separator = inputBeforeRecognition ? " " : "";
                    chatInput.value = inputBeforeRecognition + separator + recognizedText;
                }
            };

            recognition.onerror = event => {
                const messages = {
                    "not-allowed": assistantLanguage === "hi" ? "माइक्रोफ़ोन की अनुमति नहीं मिली। ब्राउज़र सेटिंग में अनुमति देकर फिर प्रयास करें।" : "Microphone access was denied. Allow microphone access in your browser settings and try again.",
                    "service-not-allowed": assistantLanguage === "hi" ? "ब्राउज़र ने वॉइस रिकग्निशन की अनुमति नहीं दी।" : "Speech recognition is blocked by the browser.",
                    "no-speech": assistantLanguage === "hi" ? "आवाज़ नहीं मिली। कृपया फिर से प्रयास करें।" : "No speech was detected. Please try again.",
                    "audio-capture": assistantLanguage === "hi" ? "माइक्रोफ़ोन नहीं मिला। कनेक्शन जाँचें।" : "No microphone was found. Check that your microphone is connected.",
                    "network": assistantLanguage === "hi" ? "वॉइस रिकग्निशन के लिए नेटवर्क कनेक्शन आवश्यक है।" : "Speech recognition needs a working network connection."
                };
                status.textContent = messages[event.error] || (assistantLanguage === "hi"
                    ? "वॉइस इनपुट पूरा नहीं हो सका। फिर प्रयास करें या अपना सवाल टाइप करें।"
                    : "Voice input could not be completed. Please try again or type your question.");
            };

            recognition.onend = () => {
                setListening(false);
                if (finalTranscript.trim()) {
                    status.textContent = assistantLanguage === "hi"
                        ? "बोला गया टेक्स्ट जुड़ गया है। जाँचकर भेजें।"
                        : "Voice text added. Review it, then press Send.";
                    chatInput.focus();
                } else if (status.textContent.startsWith("Listening") || status.textContent.startsWith("सुन रहा")) {
                    status.textContent = assistantLanguage === "hi"
                        ? "आवाज़ दर्ज नहीं हुई। दोबारा बोलने के लिए माइक्रोफ़ोन दबाएँ।"
                        : "No speech was captured. Tap the microphone to try again.";
                }
                recognition = null;
            };

            recognition.start();
        } catch (error) {
            setListening(false);
            recognition = null;
            status.textContent = assistantLanguage === "hi"
                ? "वॉइस इनपुट शुरू नहीं हो सका। माइक्रोफ़ोन की अनुमति जाँचकर फिर प्रयास करें।"
                : "Could not start voice input. Check microphone permission and try again.";
        }
    });
})();

$("#clearChat")?.addEventListener("click", () => {
    $("#chatMessages").innerHTML = "";

    addChatMessage(assistantWelcomeMessages[assistantLanguage], "assistant");
});

/* =====================================================
   9. PERIOD-CYCLE MEAL GUIDE
   ===================================================== */

const periodMeals = [
    {
        day: 1,
        title: "Iron Support",
        breakfast: "Poha with peanuts and lemon",
        lunch: "Roti, dal, spinach sabzi and salad",
        snack: "Orange and roasted chana",
        dinner: "Vegetable khichdi with curd"
    },
    {
        day: 2,
        title: "Protein & Energy",
        breakfast: "Besan chilla with chutney",
        lunch: "Rice, rajma and cucumber salad",
        snack: "Banana and a handful of nuts",
        dinner: "Roti, paneer bhurji and vegetables"
    },
    {
        day: 3,
        title: "Fibre & Fullness",
        breakfast: "Vegetable upma with peanuts",
        lunch: "Roti, chana masala and salad",
        snack: "Guava or amla",
        dinner: "Moong dal khichdi with vegetables"
    },
    {
        day: 4,
        title: "Magnesium-Rich Foods",
        breakfast: "Oats with banana and almonds",
        lunch: "Roti, dal, beans sabzi and curd",
        snack: "Pumpkin seeds and fruit",
        dinner: "Vegetable pulao with paneer or soy chunks"
    },
    {
        day: 5,
        title: "Protein & Iron",
        breakfast: "Boiled eggs or paneer sandwich",
        lunch: "Roti, kala chana and lemon salad",
        snack: "Dates and walnuts",
        dinner: "Egg curry or dal with rice and vegetables"
    },
    {
        day: 6,
        title: "Comfort Foods",
        breakfast: "Vegetable dalia",
        lunch: "Roti, masoor dal and beetroot sabzi",
        snack: "Yogurt and fruit",
        dinner: "Vegetable soup with a paneer sandwich"
    },
    {
        day: 7,
        title: "Balanced Nutrition",
        breakfast: "Stuffed paneer paratha with curd",
        lunch: "Rice or roti, dal, seasonal vegetables and salad",
        snack: "Fruit with roasted makhana or chana",
        dinner: "Roti with mixed vegetables and dal"
    }
];

function renderPeriodMeals() {
    const grid = $("#periodMealGrid");

    if (!grid) return;

    grid.innerHTML = periodMeals.map(day => `
        <article class="period-meal-card">
            <span class="meal-tag">DAY ${day.day}</span>
            <h3>${day.title}</h3>

            <p>
                <strong>Breakfast</strong>
                ${day.breakfast}
            </p>

            <p>
                <strong>Lunch</strong>
                ${day.lunch}
            </p>

            <p>
                <strong>Evening Snack</strong>
                ${day.snack}
            </p>

            <p>
                <strong>Dinner</strong>
                ${day.dinner}
            </p>
        </article>
    `).join("");
}

function estimateCyclePhase(startDate, cycleLength) {
    const start = new Date(`${startDate}T12:00:00`);
    const today = new Date();

    today.setHours(12, 0, 0, 0);

    if (Number.isNaN(start.getTime())) {
        throw new Error("Please enter a valid period start date.");
    }

    if (start > today) {
        throw new Error("The start date cannot be in the future.");
    }

    const daysSinceStart = Math.floor(
        (today - start) / 86400000
    );

    const cycleDay = (daysSinceStart % cycleLength) + 1;

    let phase;
    let description;

    if (cycleDay <= 5) {
        phase = "Estimated menstrual phase";
        description =
            "Choose regular meals and include iron-containing foods.";
    } else if (cycleDay < Math.max(7, cycleLength - 19)) {
        phase = "Estimated follicular phase";
        description =
            "Continue varied meals with protein, vegetables and grains.";
    } else if (cycleDay <= cycleLength - 12) {
        phase = "Possible ovulation window";
        description =
            "This calendar estimate cannot confirm ovulation.";
    } else {
        phase = "Estimated luteal phase";
        description =
            "Regular meals, fluids and satisfying snacks may be helpful.";
    }

    return {
        cycleDay,
        phase,
        description
    };
}

$("#calculateCycle")?.addEventListener("click", () => {
    const startDate = $("#periodStart").value;

    const cycleLength = Number(
        $("#cycleLength").value
    );

    if (!startDate) {
        showToast("Please select the first day of your last period.");
        return;
    }

    if (
        !Number.isInteger(cycleLength) ||
        cycleLength < 21 ||
        cycleLength > 45
    ) {
        showToast("Enter a cycle length between 21 and 45 days.");
        return;
    }

    try {
        const result = estimateCyclePhase(
            startDate,
            cycleLength
        );

        $("#cycleResult").innerHTML = `
            <span class="meal-tag">CYCLE ESTIMATE</span>
            <h3>Cycle Day ${result.cycleDay}</h3>
            <h4>${result.phase}</h4>
            <p>${result.description}</p>
            <p>
                This estimate is based on the dates you entered.
                Actual cycle phases vary between individuals and cycles.
            </p>
        `;

        $("#cycleResult").classList.remove("hidden");

    } catch (error) {
        showToast(error.message);
    }
});

/* =====================================================
   10. PREGNANCY MEAL CALENDAR
   ===================================================== */

/*
 These are general meal ideas, not a trimester-specific
 clinical prescription. Food choices must be checked for
 allergies, food safety and individual medical requirements.
*/

const pregnancyMeals = [
    {
        breakfast: "Oats with pasteurized milk and fruit",
        lunch: "Roti, dal and cooked seasonal vegetables",
        snack: "Washed fruit and a handful of nuts",
        dinner: "Rice, moong dal and cooked vegetables"
    },
    {
        breakfast: "Vegetable poha with lemon",
        lunch: "Rajma, rice and cooked vegetables",
        snack: "Pasteurized yogurt and fruit",
        dinner: "Roti, paneer bhurji and vegetables"
    },
    {
        breakfast: "Besan chilla with cooked vegetables",
        lunch: "Rice, dal and spinach sabzi",
        snack: "Banana and nuts",
        dinner: "Vegetable khichdi with pasteurized curd"
    },
    {
        breakfast: "Vegetable dalia",
        lunch: "Roti, chana and cooked vegetables",
        snack: "Washed guava",
        dinner: "Rice, dal and seasonal vegetables"
    },
    {
        breakfast: "Paneer sandwich with cooked filling",
        lunch: "Rajma chawal with cooked vegetables",
        snack: "Pasteurized yogurt and fruit",
        dinner: "Roti, dal and vegetable sabzi"
    },
    {
        breakfast: "Oats with banana and almonds",
        lunch: "Roti, masoor dal and beetroot sabzi",
        snack: "Roasted chana and fruit",
        dinner: "Vegetable pulao with paneer"
    },
    {
        breakfast: "Vegetable upma",
        lunch: "Rice, dal and cooked greens",
        snack: "Fruit and pasteurized yogurt",
        dinner: "Roti, kala chana and vegetables"
    }
];

function adjustPregnancyMeals(meal, preference) {
    const adjusted = { ...meal };

    if (preference === "vegan") {
        adjusted.breakfast =
            "Oats with fortified plant milk and fruit";

        adjusted.snack =
            "Washed fruit and nuts, if tolerated";

        adjusted.dinner =
            "Rice, dal and cooked vegetables";
    }

    if (preference === "eggetarian") {
        adjusted.breakfast +=
            " or fully cooked eggs";

        adjusted.lunch =
            "Rice, dal, fully cooked egg and vegetables";
    }

    if (preference === "non-vegetarian") {
        adjusted.lunch =
            "Rice, thoroughly cooked chicken, dal and vegetables";

        adjusted.dinner =
            "Roti, thoroughly cooked egg curry and vegetables";
    }

    return adjusted;
}

function renderPregnancyCalendar() {
    const month = Number($("#pregnancyMonth").value);
    const preference = $("#pregnancyDiet").value;

    const calendar = $("#pregnancyCalendar");
    const summary = $("#pregnancySummary");

    if (!calendar || !summary) return;

    if (
        !Number.isInteger(month) ||
        month < 1 ||
        month > 9
    ) {
        showToast("Choose a pregnancy month from 1 to 9.");
        return;
    }

    summary.innerHTML = `
        <span class="meal-tag">GENERAL MEAL IDEAS</span>
        <h2>Month ${month} · 30-day calendar</h2>
        <p>
            Selected food preference:
            <strong>${preference}</strong>
        </p>
        <p>
            This is a rotating collection of meal ideas, not a medical
            plan tailored to pregnancy week, laboratory results or
            individual health conditions.
        </p>
    `;

    summary.classList.remove("hidden");

    const cards = [];

    for (let day = 1; day <= 30; day++) {
        const baseMeal =
            pregnancyMeals[(day - 1) % pregnancyMeals.length];

        const meal = adjustPregnancyMeals(
            baseMeal,
            preference
        );

        cards.push(`
            <article class="pregnancy-day-card">
                <div class="pregnancy-day-head">
                    <span>Day ${day}</span>
                    <small>Month ${month}</small>
                </div>

                <p>
                    <strong>Breakfast</strong>
                    ${meal.breakfast}
                </p>

                <p>
                    <strong>Lunch</strong>
                    ${meal.lunch}
                </p>

                <p>
                    <strong>Snack</strong>
                    ${meal.snack}
                </p>

                <p>
                    <strong>Dinner</strong>
                    ${meal.dinner}
                </p>
            </article>
        `);
    }

    calendar.innerHTML = cards.join("");

    showToast("30-day meal calendar generated.");
}

$("#generatePregnancyPlan")?.addEventListener(
    "click",
    renderPregnancyCalendar
);

/* =====================================================
   11. UTTARAKHAND LOCAL FOOD DATABASE
   ===================================================== */

/*
 Research-based prototype data.
 Restaurant menu availability must be confirmed directly.
 Nutrient information describes general food characteristics,
 not laboratory-tested values for individual dishes.
*/

const localFoods = [
    {
        id: "bhatt",
        category: "dish",
        name: "Bhatt Ki Churkani",
        place: "Kumaon, Uttarakhand",
        icon: "🥣",
        description:
            "A traditional Kumaoni dish prepared with black soybeans.",
        nutrition:
            "Black soybeans provide plant protein, fibre and minerals.",
        keywords: ["kumaoni", "bhatt", "soybean", "protein"],
        status: "Traditional dish · Nutrition varies by recipe"
    },
    {
        id: "mandua",
        category: "dish",
        name: "Mandua Roti",
        place: "Garhwal and Kumaon",
        icon: "🫓",
        description:
            "A traditional flatbread made with finger millet flour.",
        nutrition:
            "Finger millet contains fibre, calcium and carbohydrates.",
        keywords: ["mandua", "ragi", "millet", "roti", "calcium"],
        status: "Traditional food · Values depend on serving"
    },
    {
        id: "jhangora",
        category: "dish",
        name: "Jhangora Kheer",
        place: "Uttarakhand",
        icon: "🥛",
        description:
            "A dessert prepared using barnyard millet and milk.",
        nutrition:
            "Provides carbohydrates; milk contributes protein and calcium.",
        keywords: ["jhangora", "kheer", "millet", "milk"],
        status: "Traditional dish · Recipe dependent"
    },
    {
        id: "rajma",
        category: "dish",
        name: "Rajma Chawal",
        place: "Mountain regions including Chamoli",
        icon: "🍛",
        description:
            "Kidney beans served with rice, a familiar meal combination.",
        nutrition:
            "Rajma contributes plant protein and fibre; rice provides energy.",
        keywords: ["rajma", "kidney beans", "rice", "chamoli"],
        status: "General nutrition information"
    },
    {
        id: "bhatt-dal",
        category: "dish",
        name: "Kumaoni Dal",
        place: "Kumaon",
        icon: "🥣",
        description:
            "A regional lentil or pulse-based meal.",
        nutrition:
            "Pulses generally provide plant protein, fibre and minerals.",
        keywords: ["dal", "lentils", "kumaon", "protein"],
        status: "Recipe varies by household"
    },
    {
        id: "aloo",
        category: "dish",
        name: "Aloo Ke Gutke",
        place: "Kumaon",
        icon: "🥔",
        description:
            "A traditional spiced potato dish.",
        nutrition:
            "Potatoes provide carbohydrates and potassium.",
        keywords: ["potato", "aloo", "gutke", "potassium"],
        status: "Recipe and oil content vary"
    },
    {
        id: "baadi",
        category: "dish",
        name: "Baadi",
        place: "Garhwal",
        icon: "🍲",
        description:
            "A traditional preparation associated with local millet flour.",
        nutrition:
            "Millet-based foods provide carbohydrates and variable amounts of fibre.",
        keywords: ["baadi", "garhwali", "millet"],
        status: "Preparation varies"
    },
    {
        id: "bhang",
        category: "dish",
        name: "Bhang Ki Chutney",
        place: "Uttarakhand",
        icon: "🌿",
        description:
            "A regional chutney made with hemp seeds and seasonings.",
        nutrition:
            "Hemp seeds contain fats and some protein.",
        keywords: ["bhang", "chutney", "hemp", "seeds"],
        status: "Recipe dependent"
    },
    {
        id: "malta",
        category: "produce",
        name: "Malta",
        place: "Uttarakhand hill regions",
        icon: "🍊",
        description:
            "A citrus fruit associated with the region.",
        nutrition:
            "Citrus fruit generally supplies vitamin C and water.",
        keywords: ["malta", "citrus", "vitamin c", "fruit"],
        status: "Seasonal availability varies"
    },
    {
        id: "buransh",
        category: "produce",
        name: "Buransh",
        place: "Uttarakhand hill regions",
        icon: "🌺",
        description:
            "A regional rhododendron associated with local beverages.",
        nutrition:
            "Nutrient content varies substantially by preparation.",
        keywords: ["buransh", "juice", "drink", "rhododendron"],
        status: "Preparation and availability vary"
    },
    {
        id: "litchi",
        category: "produce",
        name: "Litchi",
        place: "Dehradun",
        icon: "🍒",
        description:
            "A fruit associated with Dehradun's fruit-growing region.",
        nutrition:
            "Provides carbohydrates, water and vitamin C.",
        keywords: ["litchi", "dehradun", "fruit", "vitamin c"],
        status: "Seasonal availability varies"
    },
    {
        id: "mango",
        category: "produce",
        name: "Mango",
        place: "Dehradun",
        icon: "🥭",
        description:
            "A seasonal fruit available in the region.",
        nutrition:
            "Provides carbohydrates, fibre and vitamins.",
        keywords: ["mango", "dehradun", "vitamin a", "vitamin c"],
        status: "Seasonal availability varies"
    },
    {
        id: "guava",
        category: "produce",
        name: "Guava",
        place: "Dehradun",
        icon: "🍈",
        description:
            "A fruit that can be included in everyday meals and snacks.",
        nutrition:
            "Guava is a source of vitamin C and dietary fibre.",
        keywords: ["guava", "dehradun", "fibre", "vitamin c"],
        status: "Availability varies"
    },
    {
        id: "plum",
        category: "produce",
        name: "Plum (Aloo Bukhara)",
        place: "Nainital",
        icon: "🟣",
        description:
            "A seasonal stone fruit associated with hill markets.",
        nutrition:
            "Provides carbohydrates, fibre and plant compounds.",
        keywords: ["plum", "aloo bukhara", "nainital"],
        status: "Seasonal availability varies"
    },
    {
        id: "peach",
        category: "produce",
        name: "Peach",
        place: "Nainital",
        icon: "🍑",
        description:
            "A seasonal fruit found in regional hill markets.",
        nutrition:
            "Provides water, carbohydrates and some vitamin C.",
        keywords: ["peach", "nainital", "fruit"],
        status: "Seasonal availability varies"
    },
    {
        id: "apricot",
        category: "produce",
        name: "Apricot (Khubani)",
        place: "Almora",
        icon: "🍑",
        description:
            "A fruit grown in parts of the hill region.",
        nutrition:
            "Provides fibre and carotenoids; dried fruit is more concentrated.",
        keywords: ["apricot", "khubani", "almora", "vitamin a"],
        status: "Availability varies"
    },
    {
        id: "walnut",
        category: "produce",
        name: "Walnut",
        place: "Almora",
        icon: "🌰",
        description:
            "A nut associated with Himalayan agricultural areas.",
        nutrition:
            "Contains unsaturated fats, including alpha-linolenic acid.",
        keywords: ["walnut", "almora", "omega 3", "protein"],
        status: "General nutrition information"
    },
    {
        id: "amaranth",
        category: "produce",
        name: "Amaranth (Chaulai)",
        place: "Pithoragarh",
        icon: "🌿",
        description:
            "A leafy vegetable or grain used in regional cooking.",
        nutrition:
            "Provides varying amounts of protein, iron and magnesium.",
        keywords: ["amaranth", "chaulai", "pithoragarh"],
        status: "Nutrition depends on the part and preparation"
    },
    {
        id: "potato",
        category: "produce",
        name: "Potato",
        place: "Chamoli",
        icon: "🥔",
        description:
            "A commonly used crop in mountain food systems.",
        nutrition:
            "Provides carbohydrates and potassium.",
        keywords: ["potato", "chamoli", "potassium"],
        status: "Availability varies"
    },
    {
        id: "apple",
        category: "produce",
        name: "Apple",
        place: "Uttarkashi",
        icon: "🍎",
        description:
            "A fruit associated with Uttarkashi's hill-growing areas.",
        nutrition:
            "Provides carbohydrates, fibre and plant compounds.",
        keywords: ["apple", "uttarkashi", "fibre"],
        status: "Seasonal availability varies"
    },
    {
        id: "red-rice",
        category: "produce",
        name: "Red Rice",
        place: "Uttarkashi",
        icon: "🍚",
        description:
            "A rice variety used in some regional food traditions.",
        nutrition:
            "Whole-grain red rice can provide carbohydrates, fibre and minerals.",
        keywords: ["red rice", "uttarkashi", "rice", "minerals"],
        status: "Variety and availability vary"
    },

    /* Trek-area restaurants from the supplied research */

    {
        id: "evergreen",
        category: "restaurant",
        name: "The Evergreen Cafe",
        place: "Chopta · Tungnath-Chandrashila Trek",
        icon: "☕",
        description:
            "The research document describes breakfast platters, hot drinks, " +
            "Indian meals and some international dishes.",
        nutrition:
            "Ask whether vegetable sandwiches, omelettes, rice-dal meals or parathas are available.",
        keywords: [
            "evergreen", "cafe", "chopta", "trek",
            "omelette", "sandwich", "dal", "paratha"
        ],
        status: "Research listing · Confirm current menu"
    },
    {
        id: "hansuli",
        category: "restaurant",
        name: "Hansuli Homestay",
        place: "Sari Village · Chopta area",
        icon: "🏡",
        description:
            "The supplied research lists poha, upma, besan chilla, " +
            "paneer paratha, dal, rajma-rice and vegetable dishes.",
        nutrition:
            "Dal, besan, eggs and paneer can contribute protein; rice or roti adds energy.",
        keywords: [
            "hansuli", "homestay", "sari", "chopta",
            "poha", "besan", "paneer", "rajma"
        ],
        status: "Research listing · Confirm current menu"
    },
    {
        id: "shivansh",
        category: "restaurant",
        name: "Shivansh Cafe Resto N Rooms",
        place: "Sari Village · Deoria Tal trail area",
        icon: "🍽️",
        description:
            "The supplied research describes Indian and Chinese food, " +
            "breakfast, lunch, dinner and vegan options.",
        nutrition:
            "Ask whether dal-rice, rajma, chana, paneer or breakfast dishes are available.",
        keywords: [
            "shivansh", "sari", "deoria tal", "vegan",
            "dal", "rice", "paneer", "breakfast"
        ],
        status: "Suggested dishes are unconfirmed · Ask first"
    },
    {
        id: "buransh-cafe",
        category: "restaurant",
        name: "Cafe Buransh",
        place: "Near the Deoria Tal trekking route from Sari",
        icon: "🌺",
        description:
            "The research describes a homestay with an attached restaurant " +
            "serving local dishes, mains, snacks and beverages.",
        nutrition:
            "Ask about Garhwali thali, mandua roti, dal-rice, seasonal vegetables and packed meals.",
        keywords: [
            "cafe buransh", "deoria tal", "sari",
            "garhwali", "mandua", "packed meals"
        ],
        status: "Suggested dishes are unconfirmed · Ask first"
    }
];

/* =====================================================
   12. LOCAL FOOD SEARCH AND FILTERING
   ===================================================== */

function renderLocalFoods() {
    const grid = $("#localFoodGrid");

    if (!grid) return;

    const search = (
        $("#localSearch")?.value || ""
    ).trim().toLowerCase();

    const category =
        $("#localCategory")?.value || "all";

    const filtered = localFoods.filter(food => {
        const matchesCategory =
            category === "all" ||
            food.category === category;

        const searchable = [
            food.name,
            food.place,
            food.description,
            food.nutrition,
            ...food.keywords
        ].join(" ").toLowerCase();

        const matchesSearch =
            !search || searchable.includes(search);

        return matchesCategory && matchesSearch;
    });

    const count = $("#localResultCount");

    if (count) {
        count.textContent =
            `${filtered.length} result${filtered.length === 1 ? "" : "s"} found`;
    }

    if (!filtered.length) {
        grid.innerHTML = `
            <div class="empty-state">
                <span>🔎</span>
                <h3>No matching local foods found</h3>
                <p>
                    Try another food name, town, locality or category.
                </p>
            </div>
        `;

        return;
    }

    grid.innerHTML = filtered.map(food => `
        <article class="local-food-card">

            <div class="local-card-top">
                <span class="local-icon">${food.icon}</span>

                <span class="meal-tag">
                    ${
                        food.category === "dish"
                            ? "Regional dish"
                            : food.category === "produce"
                                ? "Local produce"
                                : "Food stop"
                    }
                </span>
            </div>

            <h3>${food.name}</h3>

            <p class="local-place">
                📍 ${food.place}
            </p>

            <p>${food.description}</p>

            <div class="local-nutrition">
                <strong>Nutrition information</strong>
                <p>${food.nutrition}</p>
            </div>

            <span class="verification-status">
                ℹ️ ${food.status}
            </span>

        </article>
    `).join("");
}

$("#localSearch")?.addEventListener(
    "input",
    renderLocalFoods
);

$("#localCategory")?.addEventListener(
    "change",
    renderLocalFoods
);

/* =====================================================
   13. PROFILE BMI DISPLAY (uses the existing profile fields)
   ===================================================== */

function getBMIValues(weightValue, heightValue) {
    const weight = Number(weightValue);
    const heightCm = Number(heightValue);
    if (!weightValue || !heightValue || !Number.isFinite(weight) || !Number.isFinite(heightCm) || weight <= 0 || heightCm <= 0) {
        return null;
    }
    const bmi = weight / Math.pow(heightCm / 100, 2);
    if (!Number.isFinite(bmi) || bmi <= 0 || bmi > 1000) return null;
    let category;
    if (bmi < 18.5) category = "Underweight";
    else if (bmi < 25) category = "Normal Weight";
    else if (bmi < 30) category = "Overweight";
    else category = "Obese";
    return { value: Number(bmi.toFixed(1)), category };
}

function updateBMIDisplay() {
    const value = $("#bmiValue");
    const category = $("#bmiCategory");
    const display = $("#bmiDisplay");
    if (!value || !category || !display) return;
    const weight = $("#weight")?.value || "";
    const height = $("#height")?.value || "";
    const bmi = getBMIValues(weight, height);
    if (!bmi) {
        value.textContent = "—";
        category.textContent = "Please complete your profile by entering height and weight.";
        display.dataset.category = "incomplete";
        return;
    }
    value.textContent = String(bmi.value);
    category.textContent = bmi.category;
    display.dataset.category = bmi.category.toLowerCase().replace(/\s+/g, "-");
}

["#height", "#weight"].forEach(selector => {
    $(selector)?.addEventListener("input", updateBMIDisplay);
    $(selector)?.addEventListener("change", updateBMIDisplay);
});

/* =====================================================
   14. ONLINE CONSULTATION (fictional demo data only)
   ===================================================== */

const CONSULTATIONS_KEY = "nutriNovaConsultations";
const CONSULTATION_DEMO_PROS = [
    {
        id: "demo-ananya-rao", name: "Dr. Ananya Rao", qualification: "M.Sc. Clinical Nutrition · Ph.D. Nutrition (sample profile)", specialization: "Clinical Nutrition", experience: 9, fee: 650, languages: ["English", "Hindi", "Marathi"], availability: "Mon–Fri · 10:00 AM–5:00 PM", slots: ["10:00 AM", "11:30 AM", "2:00 PM", "4:30 PM"], rating: 4.9, reviewsCount: 128, modalities: ["Video", "Audio", "Chat"],
        bio: "A fictional clinical nutrition profile focused on balanced eating habits, meal-planning education, and practical nutrition routines for everyday life. This sample biography is not a real credential or offer of care.",
        reviews: [{ rating: 5, quote: "The example profile explains food planning in a clear, practical way.", author: "Sample reviewer · A.K." }, { rating: 5, quote: "Helpful and easy-to-follow educational suggestions.", author: "Sample reviewer · M.R." }]
    },
    {
        id: "demo-rohan-mehta", name: "Dr. Rohan Mehta", qualification: "M.Sc. Sports Nutrition · Certified Sports Nutrition (sample profile)", specialization: "Sports Nutrition", experience: 7, fee: 550, languages: ["English", "Hindi", "Punjabi"], availability: "Mon–Sat · 4:00 PM–8:00 PM", slots: ["4:00 PM", "5:00 PM", "6:30 PM", "7:30 PM"], rating: 4.8, reviewsCount: 96, modalities: ["Video", "Audio", "Chat"],
        bio: "A fictional sports-nutrition profile interested in food habits for training days, practical snack ideas, and general education about protein-rich foods. No real professional relationship is offered.",
        reviews: [{ rating: 5, quote: "Good sample ideas for organizing meals around activity.", author: "Sample reviewer · S.P." }, { rating: 4, quote: "Clear explanations and realistic everyday examples.", author: "Sample reviewer · V.K." }]
    },
    {
        id: "demo-meera-iyer", name: "Dr. Meera Iyer", qualification: "M.Sc. Food & Nutrition · RD-style sample qualification", specialization: "Weight Management Education", experience: 11, fee: 700, languages: ["English", "Hindi", "Tamil"], availability: "Tue–Sat · 9:00 AM–1:00 PM", slots: ["9:00 AM", "10:30 AM", "12:00 PM", "1:00 PM"], rating: 5.0, reviewsCount: 142, modalities: ["Video", "Audio", "Chat"],
        bio: "A fictional profile presenting non-stigmatizing weight and portion education, routine-building ideas, and the importance of individualized guidance from qualified professionals.",
        reviews: [{ rating: 5, quote: "The example language feels supportive rather than judgmental.", author: "Sample reviewer · N.S." }, { rating: 5, quote: "Useful reminders about sustainable routines.", author: "Sample reviewer · P.D." }]
    },
    {
        id: "demo-farah-khan", name: "Farah Khan", qualification: "M.Sc. Dietetics · Community Nutrition (sample profile)", specialization: "Family Nutrition", experience: 6, fee: 450, languages: ["English", "Hindi", "Urdu"], availability: "Mon–Fri · 11:00 AM–6:00 PM", slots: ["11:00 AM", "1:30 PM", "3:00 PM", "5:30 PM"], rating: 4.7, reviewsCount: 73, modalities: ["Video", "Audio", "Chat"],
        bio: "A fictional community and family nutrition profile featuring budget-aware meal ideas, family meal organization, and culturally familiar food choices for educational use.",
        reviews: [{ rating: 5, quote: "Nice sample ideas for making family meals more varied.", author: "Sample reviewer · R.A." }, { rating: 4, quote: "The budget focus is easy to understand.", author: "Sample reviewer · K.T." }]
    },
    {
        id: "demo-ishita-bose", name: "Dr. Ishita Bose", qualification: "M.Sc. Nutrition · Public Health Nutrition (sample profile)", specialization: "Public Health Nutrition", experience: 8, fee: 500, languages: ["English", "Hindi", "Bengali"], availability: "Mon–Thu · 12:00 PM–7:00 PM", slots: ["12:00 PM", "2:30 PM", "4:00 PM", "6:30 PM"], rating: 4.8, reviewsCount: 88, modalities: ["Video", "Audio", "Chat"],
        bio: "A fictional public-health nutrition profile covering food literacy, seasonal produce, label reading, and community-level nutrition education in an accessible style.",
        reviews: [{ rating: 5, quote: "A thoughtful sample profile with practical food-literacy themes.", author: "Sample reviewer · D.B." }, { rating: 4, quote: "Clear explanations of everyday nutrition basics.", author: "Sample reviewer · A.C." }]
    },
    {
        id: "demo-kabir-singh", name: "Kabir Singh", qualification: "M.Sc. Food Science & Nutrition (sample profile)", specialization: "Vegetarian Nutrition", experience: 5, fee: 400, languages: ["English", "Hindi", "Punjabi"], availability: "Mon–Sat · 8:00 AM–12:00 PM", slots: ["8:00 AM", "9:30 AM", "11:00 AM", "12:00 PM"], rating: 4.6, reviewsCount: 61, modalities: ["Video", "Audio", "Chat"],
        bio: "A fictional vegetarian-food education profile interested in everyday pulses, grains, dairy alternatives, and meal variety. It is provided for software demonstration only.",
        reviews: [{ rating: 5, quote: "Helpful sample swaps with familiar vegetarian foods.", author: "Sample reviewer · H.G." }, { rating: 4, quote: "Easy-to-read explanations.", author: "Sample reviewer · M.J." }]
    },
    {
        id: "demo-neha-verma", name: "Dr. Neha Verma", qualification: "M.Sc. Nutrition · Maternal & Child Nutrition (sample profile)", specialization: "Maternal & Child Nutrition Education", experience: 10, fee: 750, languages: ["English", "Hindi"], availability: "Tue–Fri · 9:30 AM–3:30 PM", slots: ["9:30 AM", "11:00 AM", "1:00 PM", "3:00 PM"], rating: 4.9, reviewsCount: 117, modalities: ["Video", "Audio", "Chat"],
        bio: "A fictional maternal-and-child nutrition education profile emphasizing general food literacy and the importance of obtaining personal pregnancy or child-health advice from an appropriately qualified clinician.",
        reviews: [{ rating: 5, quote: "Good reminders to get individual advice for personal needs.", author: "Sample reviewer · L.S." }, { rating: 5, quote: "Friendly, clear wording in the sample description.", author: "Sample reviewer · T.M." }]
    },
    {
        id: "demo-vikram-nair", name: "Vikram Nair", qualification: "M.Sc. Applied Nutrition · Food Service Planning (sample profile)", specialization: "Meal Planning & Lifestyle", experience: 4, fee: 350, languages: ["English", "Hindi", "Tamil"], availability: "Wed–Sun · 3:00 PM–8:00 PM", slots: ["3:00 PM", "4:30 PM", "6:00 PM", "7:30 PM"], rating: 4.5, reviewsCount: 52, modalities: ["Video", "Audio", "Chat"],
        bio: "A fictional meal-planning profile for people exploring grocery organization, cooking schedules, and habit-friendly meal ideas. The profile and any associated review are mock content.",
        reviews: [{ rating: 5, quote: "The sample profile makes planning feel less complicated.", author: "Sample reviewer · J.R." }, { rating: 4, quote: "Useful everyday organization tips.", author: "Sample reviewer · S.W." }]
    }
];

function safeReadArray(storageKey) {
    try {
        const value = JSON.parse(localStorage.getItem(storageKey) || "[]");
        return Array.isArray(value) ? value : [];
    } catch (error) {
        console.warn(`Could not read ${storageKey}:`, error);
        return [];
    }
}

function safeWriteJSON(storageKey, value) {
    try {
        localStorage.setItem(storageKey, JSON.stringify(value));
        return true;
    } catch (error) {
        console.error(`Could not save ${storageKey}:`, error);
        showToast("Unable to save data in this browser. Check local storage availability.");
        return false;
    }
}

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, character => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[character]);
}

function getDemoProfessional(id) {
    return CONSULTATION_DEMO_PROS.find(person => person.id === id) || null;
}

function getConsultantFilters() {
    return {
        search: $("#consultantSearch")?.value.trim().toLocaleLowerCase() || "",
        specialty: $("#consultantSpecialtyFilter")?.value || "all",
        mode: $("#consultantModeFilter")?.value || "all",
        language: $("#consultantLanguageFilter")?.value || "all"
    };
}

function filterConsultants() {
    const filters = getConsultantFilters();
    return CONSULTATION_DEMO_PROS.filter(person => {
        const searchText = [person.name, person.qualification, person.specialization, person.bio, person.languages.join(" ")].join(" ").toLocaleLowerCase();
        return (!filters.search || searchText.includes(filters.search)) &&
            (filters.specialty === "all" || person.specialization === filters.specialty) &&
            (filters.mode === "all" || person.modalities.includes(filters.mode)) &&
            (filters.language === "all" || person.languages.includes(filters.language));
    });
}

function consultantCardHTML(person) {
    const initials = person.name.replace(/^Dr\.\s*/i, "").split(/\s+/).slice(0, 2).map(part => part[0] || "").join("").toUpperCase();
    return `<article class="consultant-card">
        <div class="consultant-card-top"><div class="consultant-avatar" aria-hidden="true">${escapeHTML(initials)}</div><div class="consultant-card-name"><h3>${escapeHTML(person.name)}</h3><p>${escapeHTML(person.qualification)}</p></div></div>
        <span class="consultant-rating">★ ${person.rating.toFixed(1)} <span style="font-weight:500">(${person.reviewsCount} sample reviews)</span></span>
        <p class="consultant-specialty">${escapeHTML(person.specialization)}</p>
        <p class="consultant-bio-preview">${escapeHTML(person.bio.slice(0, 120))}${person.bio.length > 120 ? "…" : ""}</p>
        <div class="consultant-facts"><span>⌁ ${person.experience} yrs experience</span><span>🌐 ${escapeHTML(person.languages.join(", "))}</span><span>✓ Demo profile</span></div>
        <div class="consultant-card-footer"><strong>₹${person.fee}<small>Sample fee · no payment</small></strong><span style="text-align:right;color:var(--muted);font-size:11px">${escapeHTML(person.availability)}</span></div>
        <div class="consultant-card-actions"><button type="button" class="view-profile-button" data-view-consultant="${escapeHTML(person.id)}">View profile</button><button type="button" class="book-profile-button" data-book-consultant="${escapeHTML(person.id)}">Book demo</button></div>
    </article>`;
}

function renderConsultantDirectory() {
    const grid = $("#consultantGrid");
    const topGrid = $("#topRatedConsultants");
    const count = $("#consultantResultCount");
    if (!grid || !topGrid || !count) return;
    const filtered = filterConsultants();
    count.textContent = `Showing ${filtered.length} of ${CONSULTATION_DEMO_PROS.length} demo specialists`;
    grid.innerHTML = filtered.length ? filtered.map(consultantCardHTML).join("") : '<div class="empty-consultation-results"><strong>No matching demo specialists</strong><p>Try another search or reset the filters.</p></div>';
    const topRated = [...CONSULTATION_DEMO_PROS].sort((a, b) => b.rating - a.rating || b.reviewsCount - a.reviewsCount).slice(0, 3);
    topGrid.innerHTML = topRated.map(consultantCardHTML).join("");
    const avgRating = CONSULTATION_DEMO_PROS.reduce((sum, person) => sum + person.rating, 0) / CONSULTATION_DEMO_PROS.length;
    $("#consultantStatCount").textContent = String(CONSULTATION_DEMO_PROS.length);
    $("#consultantStatRating").textContent = `${avgRating.toFixed(1)}/5`;
    $("#consultationStatBookings").textContent = String(safeReadArray(CONSULTATIONS_KEY).length);
}

function populateConsultantFilters() {
    const specialtySelect = $("#consultantSpecialtyFilter");
    if (!specialtySelect) return;
    const specialties = [...new Set(CONSULTATION_DEMO_PROS.map(person => person.specialization))].sort();
    specialtySelect.innerHTML = '<option value="all">All specializations</option>' + specialties.map(item => `<option value="${escapeHTML(item)}">${escapeHTML(item)}</option>`).join("");
}

let previousConsultantFocus = null;

function openConsultantModal(id) {
    const person = getDemoProfessional(id);
    const modal = $("#consultantModal");
    const content = $("#consultantModalContent");
    const bookingForm = $("#bookingForm");
    if (!person || !modal || !content || !bookingForm) return;
    previousConsultantFocus = document.activeElement;
    const initials = person.name.replace(/^Dr\.\s*/i, "").split(/\s+/).slice(0, 2).map(part => part[0] || "").join("").toUpperCase();
    const reviewHTML = person.reviews.map(review => `<article class="consultant-review"><span class="consultant-rating">★ ${review.rating}/5</span><p>“${escapeHTML(review.quote)}”</p><strong>${escapeHTML(review.author)}</strong></article>`).join("");
    content.innerHTML = `<div class="consultant-modal-profile-head"><div class="consultant-avatar" aria-hidden="true">${escapeHTML(initials)}</div><div><span class="eyebrow">FICTIONAL DEMO PROFILE</span><h2 id="consultantModalName">${escapeHTML(person.name)}</h2><p>${escapeHTML(person.qualification)}</p><span class="consultant-rating">★ ${person.rating.toFixed(1)} · ${person.reviewsCount} sample reviews</span></div></div>
        <p class="consultant-modal-bio">${escapeHTML(person.bio)}</p>
        <div class="profile-detail-chips"><span>${escapeHTML(person.specialization)}</span><span>${person.experience} years' sample experience</span><span>₹${person.fee} sample fee</span><span>${escapeHTML(person.languages.join(" · "))}</span><span>${escapeHTML(person.availability)}</span></div>
        <h3>Sample reviews</h3><div class="consultant-reviews">${reviewHTML}</div>
        <p class="muted-copy" style="margin-top:14px">All credentials, experience, ratings, availability, and reviews on this page are mock data. No real appointment or payment is created.</p>`;
    $("#bookingConsultantId").value = person.id;
    $("#bookingFee").textContent = `₹${person.fee} (sample)`;
    $("#bookingStatus").textContent = "";
    const timeSelect = $("#bookingTime");
    timeSelect.innerHTML = '<option value="">Select a time</option>' + person.slots.map(slot => `<option value="${escapeHTML(slot)}">${escapeHTML(slot)}</option>`).join("");
    const modeSelect = $("#bookingMode");
    modeSelect.innerHTML = person.modalities.map(mode => `<option value="${escapeHTML(mode)}">${escapeHTML(mode)} consultation</option>`).join("");
    const dateInput = $("#bookingDate");
    const today = new Date();
    const localToday = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
    dateInput.min = localToday;
    dateInput.value = localToday;
    modal.classList.remove("hidden");
    modal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
    $("#closeConsultantModal")?.focus();
}

function closeConsultantModal() {
    const modal = $("#consultantModal");
    if (!modal || modal.classList.contains("hidden")) return;
    modal.classList.add("hidden");
    modal.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
    if (previousConsultantFocus && typeof previousConsultantFocus.focus === "function") previousConsultantFocus.focus();
}

function renderConsultationHistory() {
    const target = $("#consultationHistory");
    if (!target) return;
    const appointments = safeReadArray(CONSULTATIONS_KEY).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
    $("#consultationStatBookings").textContent = String(appointments.length);
    if (!appointments.length) {
        target.innerHTML = '<div class="empty-consultation-results"><strong>No demo appointments yet</strong><p>Choose a demo specialist above and use the booking form to create a local sample appointment.</p></div>';
        return;
    }
    target.innerHTML = appointments.map(item => `<article class="consultation-history-card"><div class="consultation-history-head"><div><h3>${escapeHTML(item.consultantName)}</h3><p>${escapeHTML(item.specialization)}</p></div><span class="appointment-mode-badge">${escapeHTML(item.mode)} · Demo</span></div><p>📅 ${escapeHTML(item.date)} at ${escapeHTML(item.time)}</p><p>Sample fee: ₹${Number(item.fee) || 0} · Status: ${escapeHTML(item.status || "Booked")}</p><div class="appointment-id">Appointment ID: ${escapeHTML(item.appointmentId)}</div><button type="button" data-remove-appointment="${escapeHTML(item.appointmentId)}">Remove from demo history</button></article>`).join("");
}

function setupConsultationModule() {
    if (!$("#consultation")) return;
    populateConsultantFilters();
    renderConsultantDirectory();
    renderConsultationHistory();
    ["#consultantSearch", "#consultantSpecialtyFilter", "#consultantModeFilter", "#consultantLanguageFilter"].forEach(selector => {
        $(selector)?.addEventListener(selector === "#consultantSearch" ? "input" : "change", renderConsultantDirectory);
    });
    $("#resetConsultantFilters")?.addEventListener("click", () => {
        if ($("#consultantSearch")) $("#consultantSearch").value = "";
        if ($("#consultantSpecialtyFilter")) $("#consultantSpecialtyFilter").value = "all";
        if ($("#consultantModeFilter")) $("#consultantModeFilter").value = "all";
        if ($("#consultantLanguageFilter")) $("#consultantLanguageFilter").value = "all";
        renderConsultantDirectory();
    });
    document.addEventListener("click", event => {
        const viewButton = event.target.closest("[data-view-consultant]");
        const bookButton = event.target.closest("[data-book-consultant]");
        if (viewButton) openConsultantModal(viewButton.dataset.viewConsultant);
        else if (bookButton) openConsultantModal(bookButton.dataset.bookConsultant);
        const removeButton = event.target.closest("[data-remove-appointment]");
        if (removeButton) {
            const id = removeButton.dataset.removeAppointment;
            const updated = safeReadArray(CONSULTATIONS_KEY).filter(item => item.appointmentId !== id);
            if (safeWriteJSON(CONSULTATIONS_KEY, updated)) {
                renderConsultationHistory();
                renderConsultantDirectory();
                showToast("Demo appointment removed from local history.");
            }
        }
        if (event.target.closest("[data-close-consultant-modal]")) closeConsultantModal();
        const scrollButton = event.target.closest("[data-scroll-target]");
        if (scrollButton) document.getElementById(scrollButton.dataset.scrollTarget)?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
    $("#closeConsultantModal")?.addEventListener("click", closeConsultantModal);
    document.addEventListener("keydown", event => {
        if (event.key === "Escape") closeConsultantModal();
    });
    $("#bookingForm")?.addEventListener("submit", event => {
        event.preventDefault();
        const person = getDemoProfessional($("#bookingConsultantId")?.value);
        const date = $("#bookingDate")?.value || "";
        const time = $("#bookingTime")?.value || "";
        const mode = $("#bookingMode")?.value || "";
        const status = $("#bookingStatus");
        if (!person || !date || !time || !mode) {
            if (status) status.textContent = "Please choose a specialist, date, time, and consultation format.";
            return;
        }
        const chosenDate = new Date(`${date}T00:00:00`);
        const today = new Date(); today.setHours(0, 0, 0, 0);
        if (Number.isNaN(chosenDate.getTime()) || chosenDate < today) {
            if (status) status.textContent = "Please choose today or a future date.";
            return;
        }
        const appointmentId = `NN-DEMO-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
        const appointment = { appointmentId, consultantId: person.id, consultantName: person.name, specialization: person.specialization, fee: person.fee, date, time, mode, status: "Demo booking saved", createdAt: new Date().toISOString(), disclaimer: "Mock appointment only; no real consultation is scheduled." };
        const appointments = safeReadArray(CONSULTATIONS_KEY);
        appointments.push(appointment);
        if (safeWriteJSON(CONSULTATIONS_KEY, appointments)) {
            if (status) status.textContent = `Demo booking saved. Your mock appointment ID is ${appointmentId}.`;
            renderConsultationHistory();
            renderConsultantDirectory();
            showToast(`Demo appointment saved: ${appointmentId}`);
            closeConsultantModal();
            $("#consultationHistory")?.scrollIntoView({ behavior: "smooth", block: "start" });
        }
    });
}

/* =====================================================
   15. SMART BUDGET-BASED MEAL PLANNER
   ===================================================== */

const BUDGET_SETTINGS_KEY = "nutriNovaBudgetSettings";
const BUDGET_PLAN_KEY = "nutriNovaBudgetPlan";
const BUDGET_SAVINGS_KEY = "nutriNovaBudgetSavings";
const BUDGET_PRESETS = {
    student: { daily: 180, weekly: 1260, monthly: 5400, family: 1, style: "student", title: "Student Budget Plan" },
    professional: { daily: 250, weekly: 1750, monthly: 7500, family: 1, style: "professional", title: "Working Professional Plan" },
    family: { daily: 650, weekly: 4550, monthly: 19500, family: 4, style: "family", title: "Family Budget Plan" },
    protein: { daily: 300, weekly: 2100, monthly: 9000, family: 1, style: "protein", title: "High-Protein Budget Plan" }
};

const BUDGET_MEALS = [
    { id: "poha", slot: "Breakfast", name: "Pea & onion poha", cost: 20, type: "vegan", protein: 1, convenience: 3, ingredients: ["flattened rice", "peas", "onion", "lemon", "peanuts"], groceries: [{ name: "Flattened rice (poha)", qty: 65, unit: "g" }, { name: "Peas", qty: 30, unit: "g" }, { name: "Onion", qty: 30, unit: "g" }, { name: "Lemon", qty: 0.25, unit: "piece" }, { name: "Peanuts", qty: 8, unit: "g" }] },
    { id: "besan-chilla", slot: "Breakfast", name: "Besan chilla with chutney", cost: 22, type: "vegan", protein: 2, convenience: 2, ingredients: ["gram flour", "besan", "coriander", "onion", "chutney"], groceries: [{ name: "Besan", qty: 60, unit: "g" }, { name: "Onion", qty: 25, unit: "g" }, { name: "Coriander", qty: 5, unit: "g" }] },
    { id: "sprouts", slot: "Breakfast", name: "Lemon sprouts bowl", cost: 18, type: "vegan", protein: 2, convenience: 3, ingredients: ["sprouts", "moong", "lemon", "tomato"], groceries: [{ name: "Moong sprouts", qty: 100, unit: "g" }, { name: "Tomato", qty: 35, unit: "g" }, { name: "Lemon", qty: 0.25, unit: "piece" }] },
    { id: "idli", slot: "Breakfast", name: "Idli with sambar", cost: 28, type: "vegan", protein: 2, convenience: 2, ingredients: ["idli", "rice", "urad dal", "sambar", "vegetables"], groceries: [{ name: "Idli batter", qty: 140, unit: "g" }, { name: "Sambar vegetables", qty: 70, unit: "g" }, { name: "Toor dal", qty: 15, unit: "g" }] },
    { id: "oats", slot: "Breakfast", name: "Banana oats porridge", cost: 25, type: "vegetarian", protein: 2, convenience: 3, ingredients: ["oats", "banana", "milk"], groceries: [{ name: "Oats", qty: 45, unit: "g" }, { name: "Banana", qty: 1, unit: "piece" }, { name: "Milk", qty: 150, unit: "ml" }] },
    { id: "egg-toast", slot: "Breakfast", name: "Egg bhurji with toast", cost: 34, type: "egg", protein: 3, convenience: 3, ingredients: ["egg", "eggs", "bread", "onion", "tomato"], groceries: [{ name: "Eggs", qty: 2, unit: "piece" }, { name: "Bread", qty: 2, unit: "slice" }, { name: "Onion", qty: 20, unit: "g" }, { name: "Tomato", qty: 25, unit: "g" }] },
    { id: "upma", slot: "Breakfast", name: "Vegetable upma", cost: 20, type: "vegan", protein: 1, convenience: 3, ingredients: ["semolina", "suji", "carrot", "peas"], groceries: [{ name: "Semolina (suji)", qty: 60, unit: "g" }, { name: "Carrot", qty: 30, unit: "g" }, { name: "Peas", qty: 20, unit: "g" }] },
    { id: "dal-rice", slot: "Lunch", name: "Dal, rice & seasonal sabzi", cost: 42, type: "vegan", protein: 2, convenience: 2, ingredients: ["dal", "lentils", "rice", "seasonal vegetables", "oil"], groceries: [{ name: "Rice", qty: 75, unit: "g" }, { name: "Mixed dal", qty: 35, unit: "g" }, { name: "Seasonal vegetables", qty: 120, unit: "g" }] },
    { id: "rajma-rice", slot: "Lunch", name: "Rajma rice", cost: 48, type: "vegan", protein: 3, convenience: 2, ingredients: ["rajma", "kidney beans", "rice", "tomato", "onion"], groceries: [{ name: "Rajma (dry)", qty: 55, unit: "g" }, { name: "Rice", qty: 70, unit: "g" }, { name: "Tomato", qty: 50, unit: "g" }, { name: "Onion", qty: 30, unit: "g" }] },
    { id: "chole-roti", slot: "Lunch", name: "Chole with roti", cost: 40, type: "vegan", protein: 3, convenience: 2, ingredients: ["chickpeas", "chole", "roti", "wheat", "tomato", "onion"], groceries: [{ name: "Chickpeas (dry)", qty: 50, unit: "g" }, { name: "Wheat flour", qty: 65, unit: "g" }, { name: "Tomato", qty: 40, unit: "g" }, { name: "Onion", qty: 25, unit: "g" }] },
    { id: "soya-pulao", slot: "Lunch", name: "Soya chunk vegetable pulao", cost: 43, type: "vegan", protein: 4, convenience: 2, ingredients: ["soya chunks", "soy", "rice", "vegetables"], groceries: [{ name: "Soya chunks (dry)", qty: 35, unit: "g" }, { name: "Rice", qty: 65, unit: "g" }, { name: "Mixed vegetables", qty: 90, unit: "g" }] },
    { id: "curd-rice", slot: "Lunch", name: "Curd rice with cucumber", cost: 30, type: "vegetarian", protein: 1, convenience: 3, ingredients: ["curd", "yogurt", "rice", "milk", "cucumber"], groceries: [{ name: "Rice", qty: 65, unit: "g" }, { name: "Curd", qty: 100, unit: "g" }, { name: "Cucumber", qty: 50, unit: "g" }] },
    { id: "khichdi-curd", slot: "Lunch", name: "Moong dal khichdi with curd", cost: 34, type: "vegetarian", protein: 2, convenience: 3, ingredients: ["moong dal", "rice", "curd", "yogurt"], groceries: [{ name: "Rice", qty: 45, unit: "g" }, { name: "Moong dal", qty: 35, unit: "g" }, { name: "Curd", qty: 70, unit: "g" }] },
    { id: "egg-curry-rice", slot: "Lunch", name: "Egg curry with rice", cost: 56, type: "egg", protein: 4, convenience: 2, ingredients: ["egg", "eggs", "rice", "tomato", "onion"], groceries: [{ name: "Eggs", qty: 2, unit: "piece" }, { name: "Rice", qty: 70, unit: "g" }, { name: "Tomato", qty: 55, unit: "g" }, { name: "Onion", qty: 30, unit: "g" }] },
    { id: "chicken-rice", slot: "Lunch", name: "Chicken curry with rice", cost: 78, type: "nonveg", protein: 4, convenience: 2, ingredients: ["chicken", "rice", "tomato", "onion"], groceries: [{ name: "Chicken", qty: 120, unit: "g" }, { name: "Rice", qty: 70, unit: "g" }, { name: "Tomato", qty: 45, unit: "g" }, { name: "Onion", qty: 30, unit: "g" }] },
    { id: "banana-chana", slot: "Snack", name: "Banana with roasted chana", cost: 12, type: "vegan", protein: 2, convenience: 4, ingredients: ["banana", "roasted chana", "gram"], groceries: [{ name: "Banana", qty: 1, unit: "piece" }, { name: "Roasted chana", qty: 25, unit: "g" }] },
    { id: "seasonal-fruit", slot: "Snack", name: "Seasonal fruit portion", cost: 18, type: "vegan", protein: 0, convenience: 4, ingredients: ["seasonal fruit", "apple", "guava", "papaya"], groceries: [{ name: "Seasonal fruit", qty: 150, unit: "g" }] },
    { id: "peanuts", slot: "Snack", name: "Roasted peanuts", cost: 10, type: "vegan", protein: 2, convenience: 4, ingredients: ["peanuts", "groundnuts"], groceries: [{ name: "Peanuts", qty: 25, unit: "g" }] },
    { id: "sprout-chaat", slot: "Snack", name: "Seasoned sprout chaat", cost: 18, type: "vegan", protein: 2, convenience: 3, ingredients: ["sprouts", "moong", "tomato", "lemon"], groceries: [{ name: "Moong sprouts", qty: 90, unit: "g" }, { name: "Tomato", qty: 30, unit: "g" }, { name: "Lemon", qty: 0.25, unit: "piece" }] },
    { id: "curd-snack", slot: "Snack", name: "Plain curd", cost: 15, type: "vegetarian", protein: 1, convenience: 4, ingredients: ["curd", "yogurt", "milk"], groceries: [{ name: "Curd", qty: 120, unit: "g" }] },
    { id: "boiled-eggs", slot: "Snack", name: "Two boiled eggs", cost: 20, type: "egg", protein: 3, convenience: 4, ingredients: ["egg", "eggs"], groceries: [{ name: "Eggs", qty: 2, unit: "piece" }] },
    { id: "buttermilk", slot: "Snack", name: "Homemade chaas", cost: 12, type: "vegetarian", protein: 1, convenience: 4, ingredients: ["buttermilk", "curd", "yogurt", "milk"], groceries: [{ name: "Curd", qty: 60, unit: "g" }] },
    { id: "dal-roti", slot: "Dinner", name: "Dal with chapati", cost: 35, type: "vegan", protein: 2, convenience: 2, ingredients: ["dal", "lentils", "wheat", "roti", "chapati"], groceries: [{ name: "Mixed dal", qty: 35, unit: "g" }, { name: "Wheat flour", qty: 65, unit: "g" }] },
    { id: "veg-khichdi", slot: "Dinner", name: "Vegetable khichdi", cost: 30, type: "vegan", protein: 2, convenience: 3, ingredients: ["rice", "moong dal", "vegetables"], groceries: [{ name: "Rice", qty: 50, unit: "g" }, { name: "Moong dal", qty: 35, unit: "g" }, { name: "Seasonal vegetables", qty: 90, unit: "g" }] },
    { id: "soya-curry", slot: "Dinner", name: "Soya curry with rice", cost: 42, type: "vegan", protein: 4, convenience: 2, ingredients: ["soya chunks", "soy", "rice", "tomato", "onion"], groceries: [{ name: "Soya chunks (dry)", qty: 35, unit: "g" }, { name: "Rice", qty: 65, unit: "g" }, { name: "Tomato", qty: 45, unit: "g" }, { name: "Onion", qty: 25, unit: "g" }] },
    { id: "paneer-roti", slot: "Dinner", name: "Paneer bhurji with roti", cost: 58, type: "vegetarian", protein: 3, convenience: 2, ingredients: ["paneer", "milk", "roti", "wheat", "tomato", "onion"], groceries: [{ name: "Paneer", qty: 90, unit: "g" }, { name: "Wheat flour", qty: 60, unit: "g" }, { name: "Tomato", qty: 30, unit: "g" }, { name: "Onion", qty: 25, unit: "g" }] },
    { id: "egg-roti", slot: "Dinner", name: "Egg curry with roti", cost: 45, type: "egg", protein: 3, convenience: 2, ingredients: ["egg", "eggs", "roti", "wheat", "tomato", "onion"], groceries: [{ name: "Eggs", qty: 2, unit: "piece" }, { name: "Wheat flour", qty: 55, unit: "g" }, { name: "Tomato", qty: 40, unit: "g" }, { name: "Onion", qty: 25, unit: "g" }] },
    { id: "chicken-roti", slot: "Dinner", name: "Chicken curry with roti", cost: 72, type: "nonveg", protein: 4, convenience: 2, ingredients: ["chicken", "wheat", "roti", "tomato", "onion"], groceries: [{ name: "Chicken", qty: 120, unit: "g" }, { name: "Wheat flour", qty: 60, unit: "g" }, { name: "Tomato", qty: 40, unit: "g" }, { name: "Onion", qty: 25, unit: "g" }] },
    { id: "veg-pulao", slot: "Dinner", name: "Vegetable pulao with raita", cost: 40, type: "vegetarian", protein: 1, convenience: 3, ingredients: ["rice", "vegetables", "curd", "yogurt", "milk"], groceries: [{ name: "Rice", qty: 70, unit: "g" }, { name: "Mixed vegetables", qty: 100, unit: "g" }, { name: "Curd", qty: 70, unit: "g" }] }
];

const LOCAL_BUDGET_TIPS = [
    { icon: "🌾", title: "Choose local staples", text: "Rice, wheat, millets such as mandua/ragi, and seasonal staples can help make a meal plan fit local prices." },
    { icon: "🫘", title: "Use pulses regularly", text: "Dal, chickpeas, rajma, and moong are useful pantry staples; compare dry-pack prices and cook batches safely." },
    { icon: "🥬", title: "Buy seasonal produce", text: "Compare prices at local markets and choose vegetables and fruits that are in season and in good condition." },
    { icon: "🍲", title: "Cook once, plan ahead", text: "Batch-cook suitable dishes, refrigerate leftovers promptly, and use them safely within recommended storage times." },
    { icon: "🥜", title: "Affordable protein variety", text: "Consider dals, beans, roasted chana, soy chunks, eggs or dairy according to your dietary preference and tolerance." },
    { icon: "🧾", title: "Compare unit prices", text: "Check the price per kilogram or litre, plan around food already at home, and avoid buying more than you can store." }
];

const SUBSTITUTION_TIPS = [
    { title: "Paneer ↔ soya chunks or chana", text: "Use an affordable pulse or soy option when dairy costs more, provided it suits your preferences and tolerances." },
    { title: "Packaged snacks ↔ roasted chana", text: "A measured portion of roasted chana or peanuts can be a lower-cost pantry snack; avoid allergens." },
    { title: "Premium fruit ↔ seasonal fruit", text: "Choose a local seasonal fruit such as guava, banana or papaya when it is good value." },
    { title: "Expensive vegetables ↔ local seasonal vegetables", text: "Use the vegetables that are affordable and available locally, while keeping variety across the week." },
    { title: "Higher-cost grains ↔ rice, wheat or millets", text: "Rotate familiar staples based on price and preference; whole grains can be part of a varied diet." }
];

function moneyINR(amount) {
    const number = Number(amount);
    return `₹${(Number.isFinite(number) ? Math.round(number) : 0).toLocaleString("en-IN")}`;
}

function readBudgetForm() {
    return {
        dailyBudget: Number($("#dailyBudget")?.value || 0),
        weeklyBudget: Number($("#weeklyBudget")?.value || 0),
        monthlyBudget: Number($("#monthlyBudget")?.value || 0),
        budgetPeriod: $("#budgetPeriod")?.value || "weekly",
        familyMembers: Math.max(1, Math.min(30, parseInt($("#familyMembers")?.value || "1", 10) || 1)),
        style: $("#budgetPlanStyle")?.value || "balanced"
    };
}

function saveBudgetSettings(settings) {
    return safeWriteJSON(BUDGET_SETTINGS_KEY, settings);
}

function applyBudgetPreset(presetKey) {
    const preset = BUDGET_PRESETS[presetKey];
    if (!preset) return;
    $("#dailyBudget").value = String(preset.daily);
    $("#weeklyBudget").value = String(preset.weekly);
    $("#monthlyBudget").value = String(preset.monthly);
    $("#familyMembers").value = String(preset.family);
    $("#budgetPeriod").value = "weekly";
    $("#budgetPlanStyle").value = preset.style;
    document.querySelectorAll("[data-budget-preset]").forEach(button => button.classList.toggle("is-selected", button.dataset.budgetPreset === presetKey));
    if ($("#budgetStatus")) $("#budgetStatus").textContent = `${preset.title} selected. Adjust the amounts if needed, then generate your plan.`;
}

function mealFitsDiet(meal, preference) {
    const diet = String(preference || "vegetarian").toLocaleLowerCase();
    if (diet === "vegan") return meal.type === "vegan";
    if (diet === "vegetarian") return meal.type === "vegan" || meal.type === "vegetarian";
    if (diet === "eggetarian") return meal.type !== "nonveg";
    return ["vegan", "vegetarian", "egg", "nonveg"].includes(meal.type);
}

function mealAvoidedByProfile(meal, profile) {
    if (!profile) return false;
    const text = `${meal.name} ${meal.ingredients.join(" ")}`.toLocaleLowerCase();
    const allergyTerms = String(profile.allergies || "").toLocaleLowerCase().split(/[,;]+/).map(item => item.trim()).filter(Boolean);
    const intoleranceTerms = String(profile.intolerances || "").toLocaleLowerCase().split(/[,;]+/).map(item => item.trim()).filter(Boolean);
    const dislikeTerms = String(profile.dislikes || "").toLocaleLowerCase().split(/[,;]+/).map(item => item.trim()).filter(Boolean);
    const aliases = {
        "lactose": ["milk", "curd", "yogurt", "paneer", "buttermilk"],
        "dairy": ["milk", "curd", "yogurt", "paneer", "buttermilk"],
        "gluten": ["wheat", "roti", "chapati", "bread", "semolina", "suji"],
        "groundnut": ["peanut", "peanuts"],
        "peanut": ["peanut", "peanuts"],
        "soy": ["soya", "soy"],
        "egg": ["egg", "eggs"]
    };
    const expandedTerms = [...allergyTerms, ...intoleranceTerms, ...dislikeTerms].flatMap(term => [term, ...(aliases[term] || [])]);
    return expandedTerms.some(term => term && text.includes(term));
}

function getMealCandidates(slot, profile) {
    let candidates = BUDGET_MEALS.filter(meal => meal.slot === slot && mealFitsDiet(meal, profile?.dietPreference) && !mealAvoidedByProfile(meal, profile));
    // Never silently re-introduce a meal that matched a saved allergy, intolerance, or dislike.
    return candidates;
}

function scoreMeal(meal, style) {
    let score = meal.cost;
    if (style === "protein") score -= meal.protein * 12;
    if (style === "student") score -= meal.cost <= 25 ? 5 : 0;
    if (style === "professional") score -= meal.convenience * 2;
    if (style === "family") score -= meal.cost <= 45 ? 3 : 0;
    return score;
}

function chooseBudgetMenu(settings, profile) {
    const presetTitle = settings.style === "student" ? "Student Budget Plan" : settings.style === "professional" ? "Working Professional Plan" : settings.style === "family" ? "Family Budget Plan" : settings.style === "protein" ? "High-Protein Budget Plan" : "Personalized Budget Meal Plan";
    const dayDivisor = settings.budgetPeriod === "daily" ? 1 : settings.budgetPeriod === "monthly" ? 30 : 7;
    const selectedBudget = settings.budgetPeriod === "daily" ? settings.dailyBudget : settings.budgetPeriod === "monthly" ? settings.monthlyBudget : settings.weeklyBudget;
    const householdDailyBudget = selectedBudget > 0 ? selectedBudget / dayDivisor : (settings.dailyBudget || settings.weeklyBudget / 7 || settings.monthlyBudget / 30);
    const perPersonDailyBudget = householdDailyBudget / settings.familyMembers;
    const slots = ["Breakfast", "Lunch", "Snack", "Dinner"];
    const menu = slots.map(slot => {
        const candidates = getMealCandidates(slot, profile);
        const sorted = [...candidates].sort((a, b) => scoreMeal(a, settings.style) - scoreMeal(b, settings.style));
        // Under very small budgets, favour the cheapest compatible option. As room increases, prioritise the selected plan focus.
        const meal = perPersonDailyBudget < 125
            ? [...candidates].sort((a, b) => a.cost - b.cost)[0]
            : (sorted[0] || candidates[0]);
        return meal || { id: `fallback-${slot}`, slot, name: "Review ingredients before choosing a meal", cost: 15, type: "vegan", protein: 0, convenience: 0, ingredients: [], profileWarning: true, groceries: [{ name: "Choose compatible ingredients after checking profile alerts", qty: 1, unit: "portion" }] };
    });
    return { title: presetTitle, menu, selectedBudget, dayDivisor, perPersonDailyBudget, householdDailyBudget };
}

function generateBudgetPlan(settings) {
    const selectedAmount = settings.budgetPeriod === "daily" ? settings.dailyBudget : settings.budgetPeriod === "monthly" ? settings.monthlyBudget : settings.weeklyBudget;
    if (!Number.isFinite(selectedAmount) || selectedAmount <= 0) {
        const target = settings.budgetPeriod === "daily" ? "daily" : settings.budgetPeriod === "monthly" ? "monthly" : "weekly";
        if ($("#budgetStatus")) $("#budgetStatus").textContent = `Please enter a valid ${target} budget greater than ₹0, or choose a period with an entered budget.`;
        return;
    }
    if (selectedAmount > 30000000) {
        if ($("#budgetStatus")) $("#budgetStatus").textContent = "Please enter a smaller, realistic budget amount.";
        return;
    }
    const profile = getProfile();
    const normalizedSettings = { ...settings, familyMembers: Math.max(1, settings.familyMembers || 1) };
    const chosen = chooseBudgetMenu(normalizedSettings, profile);
    const dailyPerPersonCost = chosen.menu.reduce((sum, meal) => sum + meal.cost, 0);
    const dailyHouseholdCost = dailyPerPersonCost * normalizedSettings.familyMembers;
    const periodCost = dailyHouseholdCost * chosen.dayDivisor;
    const remaining = selectedAmount - periodCost;
    const usage = selectedAmount > 0 ? (periodCost / selectedAmount) * 100 : 0;
    const bmi = profile ? getBMIValues(profile.weight, profile.height) : null;
    const profileWarning = chosen.menu.some(meal => meal.profileWarning);
    const profileText = (profile
        ? `Personalized for ${profile.name || "your profile"} · ${profile.dietPreference || "diet preference not set"} · ${normalizedSettings.familyMembers} ${normalizedSettings.familyMembers === 1 ? "person" : "people"}${bmi ? ` · BMI ${bmi.value} (${bmi.category}; screening measure only)` : ""}.`
        : `General sample plan · ${normalizedSettings.familyMembers} ${normalizedSettings.familyMembers === 1 ? "person" : "people"}. Save your profile to personalize dietary preferences and check allergy/dislike details.`) + (profileWarning ? " Some saved allergy, intolerance, or dislike preferences left no matching sample meal for a slot. Review ingredients and select a suitable alternative before using this plan." : "");
    const plan = {
        id: `${Date.now()}-${normalizedSettings.style}-${normalizedSettings.budgetPeriod}-${normalizedSettings.familyMembers}`,
        title: chosen.title,
        settings: normalizedSettings,
        menuIds: chosen.menu.map(meal => meal.id),
        menu: chosen.menu.map(meal => ({ ...meal })),
        dailyPerPersonCost,
        dailyHouseholdCost,
        weeklyHouseholdCost: dailyHouseholdCost * 7,
        monthlyHouseholdCost: dailyHouseholdCost * 30,
        selectedBudget: selectedAmount,
        selectedPeriodCost: periodCost,
        budgetRemaining: remaining,
        budgetUsagePercent: usage,
        profileText,
        generatedAt: new Date().toISOString()
    };
    const oldPlan = getStoredBudgetPlan();
    if (!oldPlan || oldPlan.id !== plan.id || JSON.stringify(oldPlan.menuIds) !== JSON.stringify(plan.menuIds)) {
        const storageState = (() => { try { return JSON.parse(localStorage.getItem(BUDGET_SAVINGS_KEY) || '{"total":0,"fingerprints":[]}'); } catch (error) { return { total: 0, fingerprints: [] }; } })();
        const fingerprint = `${plan.settings.style}|${plan.settings.familyMembers}|${plan.settings.budgetPeriod}|${plan.selectedBudget}|${plan.menuIds.join(",")}|${profile?.dietPreference || "none"}`;
        if (!Array.isArray(storageState.fingerprints)) storageState.fingerprints = [];
        if (!storageState.fingerprints.includes(fingerprint)) {
            const baselineDaily = 260 * normalizedSettings.familyMembers;
            const estimatedWeeklySavings = Math.max(0, baselineDaily - plan.dailyHouseholdCost) * 7;
            storageState.total = Math.max(0, Number(storageState.total) || 0) + estimatedWeeklySavings;
            storageState.fingerprints = [...storageState.fingerprints, fingerprint].slice(-50);
            safeWriteJSON(BUDGET_SAVINGS_KEY, storageState);
        }
    }
    saveBudgetSettings(normalizedSettings);
    if (safeWriteJSON(BUDGET_PLAN_KEY, plan)) {
        renderBudgetPlan(plan);
        if ($("#budgetStatus")) $("#budgetStatus").textContent = "Your sample budget plan was generated and saved in this browser.";
        showToast("Budget meal plan generated and saved.");
    }
}

function getStoredBudgetPlan() {
    try {
        const plan = JSON.parse(localStorage.getItem(BUDGET_PLAN_KEY) || "null");
        return plan && typeof plan === "object" ? plan : null;
    } catch (error) {
        return null;
    }
}

function renderBudgetPlan(plan) {
    const results = $("#budgetResults");
    const emptyState = $("#budgetEmptyState");
    if (!results || !emptyState) return;
    if (!plan || !Array.isArray(plan.menuIds)) {
        results.classList.add("hidden");
        emptyState.classList.remove("hidden");
        return;
    }
    const settings = plan.settings || readBudgetForm();
    const familyMembers = Math.max(1, Number(settings.familyMembers) || 1);
    const menu = plan.menuIds.map((id, index) => BUDGET_MEALS.find(meal => meal.id === id) || plan.menu?.[index]).filter(Boolean);
    if (menu.length !== 4) {
        results.classList.add("hidden");
        emptyState.classList.remove("hidden");
        return;
    }
    results.classList.remove("hidden");
    emptyState.classList.add("hidden");
    $("#budgetPlanTitle").textContent = plan.title || "Your budget meal plan";
    $("#budgetPlanSummary").textContent = plan.profileText || "Sample household meal plan.";
    $("#budgetDailyCost").textContent = moneyINR(plan.dailyHouseholdCost);
    $("#budgetWeeklyCost").textContent = moneyINR(plan.weeklyHouseholdCost);
    $("#budgetMonthlyCost").textContent = moneyINR(plan.monthlyHouseholdCost);
    $("#budgetDailyNote").textContent = `${familyMembers} ${familyMembers === 1 ? "person" : "people"} · estimated food cost`;
    $("#budgetRemaining").textContent = `${Number(plan.budgetRemaining) < 0 ? "−" : ""}${moneyINR(Math.abs(Number(plan.budgetRemaining) || 0))}`;
    $("#budgetUsage").textContent = `${Math.round(Number(plan.budgetUsagePercent) || 0)}% of selected budget`;
    const overBudget = Number(plan.budgetRemaining) < 0;
    $("#budgetFitBadge").textContent = overBudget ? "Above selected budget" : "Within sample budget";
    $("#budgetFitBadge").classList.toggle("over-budget", overBudget);
    $("#budgetRemaining").style.color = overBudget ? "#9a4b25" : "";
    $("#budgetMealGrid").innerHTML = menu.map(meal => `<article class="budget-meal-card"><span class="meal-slot">${escapeHTML(meal.slot)}</span><h4>${escapeHTML(meal.name)}</h4><p>Estimated per serving · sample price</p><span class="meal-cost">${moneyINR(meal.cost * familyMembers)} <small>household cost</small></span></article>`).join("");
    const groceryMap = new Map();
    menu.forEach(meal => (meal.groceries || []).forEach(item => {
        const key = `${item.name}|${item.unit}`;
        const current = groceryMap.get(key) || { name: item.name, quantity: 0, unit: item.unit };
        current.quantity += Number(item.qty) * familyMembers * 7;
        groceryMap.set(key, current);
    }));
    const groceryItems = [...groceryMap.values()].sort((a, b) => a.name.localeCompare(b.name));
    $("#groceryListIntro").textContent = `Quantities for 7 days × ${familyMembers} ${familyMembers === 1 ? "person" : "people"}; adjust portions and pantry stock as needed.`;
    $("#budgetGroceryList").innerHTML = groceryItems.map(item => {
        const qtyText = item.unit === "piece" || item.unit === "slice" ? (Number.isInteger(item.quantity) ? item.quantity : item.quantity.toFixed(1)) : item.quantity >= 1000 ? `${(item.quantity / 1000).toFixed(2)} kg/l` : `${Math.round(item.quantity)} ${item.unit}`;
        return `<div class="grocery-item"><span>${escapeHTML(item.name)}</span><span>${escapeHTML(qtyText)}</span></div>`;
    }).join("");
    $("#groceryCost").textContent = moneyINR(plan.weeklyHouseholdCost);
    $("#budgetSubstitutions").innerHTML = SUBSTITUTION_TIPS.map(tip => `<article class="budget-tip"><strong>${escapeHTML(tip.title)}</strong><p>${escapeHTML(tip.text)}</p></article>`).join("");
    let savingsState;
    try { savingsState = JSON.parse(localStorage.getItem(BUDGET_SAVINGS_KEY) || '{"total":0}'); } catch (error) { savingsState = { total: 0 }; }
    const baselineWeekly = 260 * familyMembers * 7;
    const estimatedWeeklySaved = Math.max(0, baselineWeekly - Number(plan.weeklyHouseholdCost || 0));
    $("#budgetSavingsText").textContent = `Compared with the illustrative baseline of ${moneyINR(260)} per person/day, this plan is estimated to be ${moneyINR(estimatedWeeklySaved)} lower per week for your household.`;
    $("#budgetSavingsTotal").textContent = moneyINR(savingsState.total || 0);
    $("#localBudgetRecommendations").innerHTML = LOCAL_BUDGET_TIPS.map(tip => `<article class="local-budget-card"><span aria-hidden="true">${tip.icon}</span><h3>${escapeHTML(tip.title)}</h3><p>${escapeHTML(tip.text)}</p></article>`).join("");
}

function setupBudgetPlanner() {
    if (!$("#budgetForm")) return;
    document.querySelectorAll("[data-budget-preset]").forEach(button => button.addEventListener("click", () => applyBudgetPreset(button.dataset.budgetPreset)));
    $("#budgetForm")?.addEventListener("submit", event => {
        event.preventDefault();
        generateBudgetPlan(readBudgetForm());
    });
    $("#clearBudgetPlan")?.addEventListener("click", () => {
        if (!confirm("Clear the saved budget meal plan and budget inputs?")) return;
        localStorage.removeItem(BUDGET_PLAN_KEY);
        localStorage.removeItem(BUDGET_SETTINGS_KEY);
        $("#budgetForm")?.reset();
        document.querySelectorAll("[data-budget-preset]").forEach(button => button.classList.remove("is-selected"));
        $("#budgetStatus").textContent = "Saved budget plan cleared.";
        renderBudgetPlan(null);
        showToast("Budget plan cleared.");
    });
    try {
        const settings = JSON.parse(localStorage.getItem(BUDGET_SETTINGS_KEY) || "null");
        if (settings) {
            if ($("#dailyBudget")) $("#dailyBudget").value = settings.dailyBudget || "";
            if ($("#weeklyBudget")) $("#weeklyBudget").value = settings.weeklyBudget || "";
            if ($("#monthlyBudget")) $("#monthlyBudget").value = settings.monthlyBudget || "";
            if ($("#budgetPeriod")) $("#budgetPeriod").value = settings.budgetPeriod || "weekly";
            if ($("#familyMembers")) $("#familyMembers").value = settings.familyMembers || "";
            if ($("#budgetPlanStyle")) $("#budgetPlanStyle").value = settings.style || "balanced";
            const preset = Object.keys(BUDGET_PRESETS).find(key => BUDGET_PRESETS[key].style === settings.style && BUDGET_PRESETS[key].family === Number(settings.familyMembers));
            if (preset) document.querySelector(`[data-budget-preset="${preset}"]`)?.classList.add("is-selected");
        }
    } catch (error) { /* Invalid saved settings are ignored; the form remains usable. */ }
    renderBudgetPlan(getStoredBudgetPlan());
}

/* =====================================================
   13. INITIALIZE APPLICATION
   ===================================================== */

function initializeApp() {
    const profile = getProfile();

    if (profile) {
        populateProfileForm(profile);
    }

    updatePlannerSummary();
    updateBMIDisplay();
    renderPeriodMeals();
    renderLocalFoods();
    setupConsultationModule();
    setupBudgetPlanner();

    const pageId = location.hash.substring(1);

    if (validPages.includes(pageId)) {
        showPage(pageId);
    } else {
        showPage("home");
    }
}

document.addEventListener(
    "DOMContentLoaded",
    initializeApp
);
